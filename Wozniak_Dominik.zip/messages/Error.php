<?php
	namespace Messages;


	final class Error {
    public static $unkonwn = 'Nieoczekiwany błąd aplikacji';
    public static $databaseConnection = 'Błąd połączenia z bazą danych';
		public static $templateNotFound = 'Błąd tworzenia widoku';
		public static $query = 'Błąd zapytania do bazy danych';		
	}
