<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:25:06
  from 'C:\xampp\htdocs\projekt\templates\Sedzia\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5ae269f803_69048303',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4f2a9b4a1c04b78aee9b56056cc2e79928ea6c98' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Sedzia\\showAll.html.tpl',
      1 => 1547655550,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5ae269f803_69048303 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8486397415c3f5ae2657716_71631506', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8771773265c3f5ae2659623_71166845', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17194070605c3f5ae265c518_40654735', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20007604345c3f5ae265db75_34923043', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5214474445c3f5ae265f087_54080984', 'tbody');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10572149685c3f5ae2696070_68509177', 'footer');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_8486397415c3f5ae2657716_71631506 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_8486397415c3f5ae2657716_71631506',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista sędziów<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_437422505c3f5ae265a811_84265336 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <button type="button" class="btn btn-primary add-button"
            data-url="sedzia/formularz/"
            data-toggle="tooltip" data-placement="top" title="Dodaj sędziego">
            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj sędziego
      </button>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_8771773265c3f5ae2659623_71166845 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_8771773265c3f5ae2659623_71166845',
  ),
  'groupAction' => 
  array (
    0 => 'Block_437422505c3f5ae265a811_84265336',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_437422505c3f5ae265a811_84265336', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_17194070605c3f5ae265c518_40654735 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_17194070605c3f5ae265c518_40654735',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Imie</th>
  <th>Nazwisko</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_20007604345c3f5ae265db75_34923043 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_20007604345c3f5ae265db75_34923043',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Imie</th>
  <th class="searchable">Nazwisko</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_5214474445c3f5ae265f087_54080984 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_5214474445c3f5ae265f087_54080984',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Imie'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Nazwisko'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
sedzia/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <button type="button" class="btn btn-danger btn-sm delete-button"
          data-url="sedzia/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
/"
          data-description="<?php echo $_smarty_tpl->tpl_vars['row']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['row']->value['Nazwisko'];?>
"
          data-toggle="tooltip" data-placement="top" title="Usuń sędziego">
          <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
    </button>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
/* {block 'footer'} */
class Block_10572149685c3f5ae2696070_68509177 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_10572149685c3f5ae2696070_68509177',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
