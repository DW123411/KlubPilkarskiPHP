<?php
/* Smarty version 3.1.33, created on 2018-12-10 14:01:52
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Klub\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0e63c0e42626_39607965',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '65b6d5f4f872eb77eccea99408d01106a39553d8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Klub\\showOne.html.tpl',
      1 => 1544446896,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c0e63c0e42626_39607965 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10141406875c0e63c0e2a848_00373547', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14034266485c0e63c0e2c645_56664164', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18748872065c0e63c0e41407_39461837', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_10141406875c0e63c0e2a848_00373547 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_10141406875c0e63c0e2a848_00373547',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o klubie<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_14034266485c0e63c0e2c645_56664164 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_14034266485c0e63c0e2c645_56664164',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];?>
</h3>
        <p>Siedziba: <?php echo $_smarty_tpl->tpl_vars['data']->value['Siedziba'];?>
</p>
        <p>Opis: <?php echo $_smarty_tpl->tpl_vars['data']->value['Opis'];?>
</p>
        <p>Trener: <?php echo $_smarty_tpl->tpl_vars['coaches']->value[$_smarty_tpl->tpl_vars['data']->value['IdT']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['coaches']->value[$_smarty_tpl->tpl_vars['data']->value['IdT']]['Nazwisko'];?>
</p>
        <p class="text-right">
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="klub/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń klub">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń klub
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_18748872065c0e63c0e41407_39461837 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_18748872065c0e63c0e41407_39461837',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'footer'} */
}
