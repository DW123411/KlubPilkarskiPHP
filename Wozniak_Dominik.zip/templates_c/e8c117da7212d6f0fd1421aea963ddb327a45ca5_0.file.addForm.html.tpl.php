<?php
/* Smarty version 3.1.33, created on 2018-12-06 14:26:57
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Zawodnik\addForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0923a1bcdf16_91171849',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e8c117da7212d6f0fd1421aea963ddb327a45ca5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Zawodnik\\addForm.html.tpl',
      1 => 1544102814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./zawodnikForm.html.tpl' => 1,
  ),
),false)) {
function content_5c0923a1bcdf16_91171849 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13674010425c0923a1bc0ac6_16663795', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3983362075c0923a1bc2de9_81125333', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15390147935c0923a1bc43c1_66577011', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_13674010425c0923a1bc0ac6_16663795 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_13674010425c0923a1bc0ac6_16663795',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy zawodnik<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_3983362075c0923a1bc2de9_81125333 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_3983362075c0923a1bc2de9_81125333',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

zawodnik/dodaj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_15390147935c0923a1bc43c1_66577011 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_15390147935c0923a1bc43c1_66577011',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./zawodnikForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
