<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:25:14
  from 'C:\xampp\htdocs\projekt\templates\Sedzia\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5aea6bc692_96533695',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a425d04a99fc76afcdd7dea5321359a9df2939c7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Sedzia\\showOne.html.tpl',
      1 => 1547655538,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5aea6bc692_96533695 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5538248695c3f5aea69e2c2_52870471', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19546905215c3f5aea6a0147_51151107', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6874665015c3f5aea6b2dc7_59140367', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_5538248695c3f5aea69e2c2_52870471 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_5538248695c3f5aea69e2c2_52870471',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o sędzim<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_19546905215c3f5aea6a0147_51151107 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_19546905215c3f5aea6a0147_51151107',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['data']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];?>
</h3>
        <p class="text-right">
          <button type="button" class="btn btn-warning edit-button"
              data-url="sedzia/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"
              data-toggle="tooltip" data-placement="top" title="Modyfikuj sędziego">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Modyfikuj sędziego
          </button>
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="sedzia/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['data']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń sędziego">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń sędziego
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_6874665015c3f5aea6b2dc7_59140367 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_6874665015c3f5aea6b2dc7_59140367',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
