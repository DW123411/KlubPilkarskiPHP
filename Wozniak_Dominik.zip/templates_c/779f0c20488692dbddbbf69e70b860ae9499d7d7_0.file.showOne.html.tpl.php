<?php
/* Smarty version 3.1.33, created on 2018-12-12 16:22:27
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\ZawodnikMecz\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c1127b30f2c25_44121372',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '779f0c20488692dbddbbf69e70b860ae9499d7d7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\ZawodnikMecz\\showOne.html.tpl',
      1 => 1544627278,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c1127b30f2c25_44121372 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13493899725c1127b30bd459_11507808', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12844134855c1127b30bf9e8_85903940', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13137810865c1127b30f1638_67292175', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_13493899725c1127b30bd459_11507808 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_13493899725c1127b30bd459_11507808',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o występie zawodnika<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_12844134855c1127b30bf9e8_85903940 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_12844134855c1127b30bf9e8_85903940',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['data']->value['IdZ']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['data']->value['IdZ']]['Nazwisko'];?>
</h3>
        <p>Mecz: <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['IdKlubGoscie']]['Nazwa'];?>
</p>
        <p>Data: <?php echo $_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['Data'];?>
</p>
        <p>Pozycja: <?php echo $_smarty_tpl->tpl_vars['data']->value['Pozycja'];?>
</p>
        <p>Czas gry: <?php echo $_smarty_tpl->tpl_vars['data']->value['MinutyOd'];?>
-<?php echo $_smarty_tpl->tpl_vars['data']->value['MinutyDo'];?>
</p>
        <p>Bramki: <?php echo $_smarty_tpl->tpl_vars['data']->value['Bramki'];?>
</p>
        <p>Asysty: <?php echo $_smarty_tpl->tpl_vars['data']->value['Asysty'];?>
</p>
        <p>Kartki żółte: <?php echo $_smarty_tpl->tpl_vars['data']->value['KartkiZolte'];?>
</p>
        <p>Kartki czerwone: <?php echo $_smarty_tpl->tpl_vars['data']->value['KartkiCzerwone'];?>
</p>
        <p>Podania udane/nieudane: <?php echo $_smarty_tpl->tpl_vars['data']->value['PodaniaUdane'];?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value['PodaniaNieudane'];?>
</p>
        <p class="text-right">
          <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnikmecz/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" type="button" class="btn btn-danger btn-sm delete-button"
              data-toggle="tooltip" data-placement="top" title="Usuń">
              <span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń występ zawodnika
          </a>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_13137810865c1127b30f1638_67292175 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_13137810865c1127b30f1638_67292175',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'footer'} */
}
