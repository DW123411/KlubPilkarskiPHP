<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:15:09
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\addKlub.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d0dbde72b04_12604578',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd3e746c00135049f4877f64f13caf19e1b247a76' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\addKlub.html.tpl',
      1 => 1546456455,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Klub/klubForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2d0dbde72b04_12604578 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12710285715c2d0dbde616c7_72588825', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13168930895c2d0dbde63818_05865974', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5642119115c2d0dbde655a3_18480735', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1936225835c2d0dbde714f1_39442257', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_12710285715c2d0dbde616c7_72588825 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_12710285715c2d0dbde616c7_72588825',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
klub/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_13168930895c2d0dbde63818_05865974 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_13168930895c2d0dbde63818_05865974',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy klub<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_5642119115c2d0dbde655a3_18480735 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_5642119115c2d0dbde655a3_18480735',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../Klub/klubForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_1936225835c2d0dbde714f1_39442257 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_1936225835c2d0dbde714f1_39442257',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
