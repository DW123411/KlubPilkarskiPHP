<?php
/* Smarty version 3.1.33, created on 2019-01-12 17:42:22
  from 'C:\xampp\htdocs\projekt\templates\Zawodnik\zawodnikForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3a18ee6e5576_49178514',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '533491ac17b302d4dac8712a13835724cb55be27' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Zawodnik\\zawodnikForm.html.tpl',
      1 => 1547311333,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c3a18ee6e5576_49178514 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\projekt\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="form-group has-feedback">
  <label for="imie">Imię</label>
  <input class="form-control" id="imie" name="imie" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Imie'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Imie'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="40"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="nazwisko">Nazwisko</label>
  <input class="form-control" id="nazwisko" name="nazwisko" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Nazwisko'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="50"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="opis">Opis</label>
  <input class="form-control" id="opis" name="opis" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Opis'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Opis'];
}?>"
    type="text"
    maaxlength='150'>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idk">Klub</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdK'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idk','options'=>$_smarty_tpl->tpl_vars['clubs']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdK']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idk','options'=>$_smarty_tpl->tpl_vars['clubs']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<?php }
}
