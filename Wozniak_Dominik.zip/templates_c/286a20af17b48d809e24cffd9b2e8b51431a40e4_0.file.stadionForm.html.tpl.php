<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:30:57
  from 'C:\xampp\htdocs\projekt\templates\Stadion\stadionForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d1171edfd25_84920330',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '286a20af17b48d809e24cffd9b2e8b51431a40e4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Stadion\\stadionForm.html.tpl',
      1 => 1546368467,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2d1171edfd25_84920330 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group has-feedback">
  <label for="miejscowosc">Miejscowość</label>
  <input class="form-control" id="miejscowosc" name="miejscowosc" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Miejscowosc'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Miejscowosc'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="90"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="nazwa">Nazwa</label>
  <input class="form-control" id="nazwa" name="nazwa" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Nazwa'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="70"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="pojemnosc">Pojemność</label>
  <input class="form-control" id="pojemnosc" name="pojemnosc" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Pojemnosc'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Pojemnosc'];
}?>"
    type="text"
    maxlength="50"
    data-required-error="Pole wymagane"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<?php }
}
