<?php
/* Smarty version 3.1.33, created on 2018-12-20 15:29:21
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Mecz\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c1ba741232e45_38096935',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f14bbb45a6fd8fd398fb9bc711dfa3e57adca7b8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Mecz\\showAll.html.tpl',
      1 => 1545316070,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c1ba741232e45_38096935 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1292948185c1ba74120d792_75339655', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3670502345c1ba74120f3e7_38702888', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12182066075c1ba74121c6b7_11145723', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8158758685c1ba74121e711_62926913', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9935071815c1ba741220258_92481500', 'tbody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_1292948185c1ba74120d792_75339655 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1292948185c1ba74120d792_75339655',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista meczy<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_20665313685c1ba741210bd1_44057173 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/formularz/" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Dodaj mecz">
      <span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span>
        Dodaj mecz
    </a>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_3670502345c1ba74120f3e7_38702888 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_3670502345c1ba74120f3e7_38702888',
  ),
  'groupAction' => 
  array (
    0 => 'Block_20665313685c1ba741210bd1_44057173',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20665313685c1ba741210bd1_44057173', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_12182066075c1ba74121c6b7_11145723 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_12182066075c1ba74121c6b7_11145723',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Data</th>
  <th>Mecz</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_8158758685c1ba74121e711_62926913 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_8158758685c1ba74121e711_62926913',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Data</th>
  <th class="searchable">Mecz</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_9935071815c1ba741220258_92481500 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_9935071815c1ba741220258_92481500',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Data'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['row']->value['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['row']->value['IdKlubGoscie']]['Nazwa'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-danger btn-sm delete-button"
        data-toggle="tooltip" data-placement="top" title="Usuń">
        <span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span>
    </a>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
}
