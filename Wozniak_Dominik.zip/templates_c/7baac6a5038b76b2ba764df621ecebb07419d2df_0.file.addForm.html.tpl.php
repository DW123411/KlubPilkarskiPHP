<?php
/* Smarty version 3.1.33, created on 2018-12-11 13:35:51
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Sezon\addForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0faf27e5ba00_14533733',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7baac6a5038b76b2ba764df621ecebb07419d2df' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Sezon\\addForm.html.tpl',
      1 => 1544531573,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./sezonForm.html.tpl' => 1,
  ),
),false)) {
function content_5c0faf27e5ba00_14533733 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1847673355c0faf27e49718_88861764', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14768164385c0faf27e4bec5_02562667', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16044205415c0faf27e4d3c8_07020696', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_1847673355c0faf27e49718_88861764 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1847673355c0faf27e49718_88861764',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy sezon<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_14768164385c0faf27e4bec5_02562667 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_14768164385c0faf27e4bec5_02562667',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

sezon/dodaj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_16044205415c0faf27e4d3c8_07020696 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_16044205415c0faf27e4d3c8_07020696',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./sezonForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
