<?php
/* Smarty version 3.1.33, created on 2018-12-12 16:24:57
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\ZawodnikMecz\addForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c1128495c2754_31716624',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '57ad09c209917f84d9eab166fbfe76bd6e324c2c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\ZawodnikMecz\\addForm.html.tpl',
      1 => 1544627321,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./zawodnikmeczForm.html.tpl' => 1,
  ),
),false)) {
function content_5c1128495c2754_31716624 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13212009085c112849574213_44863962', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15438128795c112849576864_97093022', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9019784785c1128495785e4_81042711', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_13212009085c112849574213_44863962 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_13212009085c112849574213_44863962',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy występ zawodnika w meczu<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_15438128795c112849576864_97093022 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_15438128795c112849576864_97093022',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

zawodnikmecz/dodaj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_9019784785c1128495785e4_81042711 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_9019784785c1128495785e4_81042711',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./zawodnikmeczForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
