<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:28:00
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\addSezon.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d10c07e1ca5_02213309',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1f5fd6fb9f7ba22185e16874bf8b92a62a2977e5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\addSezon.html.tpl',
      1 => 1546457230,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Sezon/sezonForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2d10c07e1ca5_02213309 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5965209345c2d10c07d1828_71461635', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1285690775c2d10c07d3d20_36044025', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9923870725c2d10c07d59f0_92555234', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16226107655c2d10c07e0ad8_11576032', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_5965209345c2d10c07d1828_71461635 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_5965209345c2d10c07d1828_71461635',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
sezon/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_1285690775c2d10c07d3d20_36044025 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1285690775c2d10c07d3d20_36044025',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy sezon<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_9923870725c2d10c07d59f0_92555234 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_9923870725c2d10c07d59f0_92555234',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../Sezon/sezonForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_16226107655c2d10c07e0ad8_11576032 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_16226107655c2d10c07e0ad8_11576032',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
