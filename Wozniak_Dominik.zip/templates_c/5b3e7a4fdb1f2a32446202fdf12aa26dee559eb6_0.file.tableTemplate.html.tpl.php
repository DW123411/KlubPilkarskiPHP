<?php
/* Smarty version 3.1.33, created on 2019-01-02 19:54:54
  from 'C:\xampp\htdocs\projekt\templates\tableTemplate.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d08fe0d99e5_07385782',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5b3e7a4fdb1f2a32446202fdf12aa26dee559eb6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\tableTemplate.html.tpl',
      1 => 1546435017,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c2d08fe0d99e5_07385782 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18450331485c2d08fe0a1414_89426452', 'body');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11488333635c2d08fe0c55f8_36009604', 'footer');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "./baseTemplate.html.tpl");
}
/* {block 'checkableFormHeader'} */
class Block_1751705415c2d08fe0a9e47_95345550 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_16682831675c2d08fe0ab315_28906511 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    				<th></th>
    				<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_7921007205c2d08fe0ac793_46365769 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    				  <th></th>
    					<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_541670205c2d08fe0bfed1_02048545 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    				<th></th>
    				<?php
}
}
/* {/block 'tbody'} */
/* {block 'checkableFormFooter'} */
class Block_11366199585c2d08fe0c2062_47376322 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'checkableFormFooter'} */
/* {block 'body'} */
class Block_18450331485c2d08fe0a1414_89426452 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_18450331485c2d08fe0a1414_89426452',
  ),
  'checkableFormHeader' => 
  array (
    0 => 'Block_1751705415c2d08fe0a9e47_95345550',
  ),
  'thead' => 
  array (
    0 => 'Block_16682831675c2d08fe0ab315_28906511',
  ),
  'tfoot' => 
  array (
    0 => 'Block_7921007205c2d08fe0ac793_46365769',
  ),
  'tbody' => 
  array (
    0 => 'Block_541670205c2d08fe0bfed1_02048545',
  ),
  'checkableFormFooter' => 
  array (
    0 => 'Block_11366199585c2d08fe0c2062_47376322',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if (isset($_smarty_tpl->tpl_vars['data']->value)) {?>
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1751705415c2d08fe0a9e47_95345550', 'checkableFormHeader', $this->tplIndex);
?>

    <!-- BEGIN TABLE WITH DATA -->
    <table id="datatable" class="display table table-striped" cellspacing="0" width="100%">
        <thead><tr>
    				<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16682831675c2d08fe0ab315_28906511', 'thead', $this->tplIndex);
?>

        </tr></thead>
    		<tfoot><tr>
    					<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7921007205c2d08fe0ac793_46365769', 'tfoot', $this->tplIndex);
?>

    	  </tr></tfoot>
        <tbody>
          <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'row', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['row']->value) {
?>
    			<tr <?php if (isset($_smarty_tpl->tpl_vars['row']->value['noSelectable']) && $_smarty_tpl->tpl_vars['row']->value['noSelectable'] === true) {?>class="noSelectable"<?php }?>>
    				<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_541670205c2d08fe0bfed1_02048545', 'tbody', $this->tplIndex);
?>

    			</tr>
          <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
      </table><!-- END TABLE WITH DATA -->
      <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11366199585c2d08fe0c2062_47376322', 'checkableFormFooter', $this->tplIndex);
?>

  <?php }
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_11488333635c2d08fe0c55f8_36009604 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_11488333635c2d08fe0c55f8_36009604',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:./modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
