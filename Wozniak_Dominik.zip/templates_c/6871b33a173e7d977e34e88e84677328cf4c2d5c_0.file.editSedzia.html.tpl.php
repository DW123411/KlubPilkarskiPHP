<?php
/* Smarty version 3.1.33, created on 2019-01-14 14:07:13
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editSedzia.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3c8981776f77_29973957',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6871b33a173e7d977e34e88e84677328cf4c2d5c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editSedzia.html.tpl',
      1 => 1547469582,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Sedzia/sedziaForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3c8981776f77_29973957 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_159298135c3c8981747ad3_55533109', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7210151745c3c8981749f15_44530588', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15321333625c3c898174bf13_38631262', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6237269215c3c89817759e8_50762169', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_159298135c3c8981747ad3_55533109 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_159298135c3c8981747ad3_55533109',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
sedzia/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_7210151745c3c8981749f15_44530588 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_7210151745c3c8981749f15_44530588',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj sędziego<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_15321333625c3c898174bf13_38631262 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_15321333625c3c898174bf13_38631262',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../Sedzia/sedziaForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_6237269215c3c89817759e8_50762169 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_6237269215c3c89817759e8_50762169',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
