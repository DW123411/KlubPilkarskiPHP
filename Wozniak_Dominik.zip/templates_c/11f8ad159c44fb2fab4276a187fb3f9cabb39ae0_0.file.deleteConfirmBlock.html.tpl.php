<?php
/* Smarty version 3.1.33, created on 2019-01-02 14:17:03
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\modals\deleteConfirmBlock.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2cb9cf0b1887_76341147',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11f8ad159c44fb2fab4276a187fb3f9cabb39ae0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\modals\\deleteConfirmBlock.html.tpl',
      1 => 1537525716,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./formBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c2cb9cf0b1887_76341147 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15151566945c2cb9cf0aba36_73464683', 'id');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11342429825c2cb9cf0ad0f1_28439786', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_53810145c2cb9cf0ae641_73354036', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13861571245c2cb9cf0b08a9_72900661', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./base.html.tpl");
}
/* {block 'id'} */
class Block_15151566945c2cb9cf0aba36_73464683 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'id' => 
  array (
    0 => 'Block_15151566945c2cb9cf0aba36_73464683',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
delete-confirm-modal<?php
}
}
/* {/block 'id'} */
/* {block 'title'} */
class Block_11342429825c2cb9cf0ad0f1_28439786 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_11342429825c2cb9cf0ad0f1_28439786',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Usuwanie danych<?php
}
}
/* {/block 'title'} */
/* {block 'content'} */
class Block_53810145c2cb9cf0ae641_73354036 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_53810145c2cb9cf0ae641_73354036',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:./formBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'content'} */
/* {block 'acceptButton'} */
class Block_13861571245c2cb9cf0b08a9_72900661 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_13861571245c2cb9cf0b08a9_72900661',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <button type="submit" class="btn btn-danger">Usuń</button>
<?php
}
}
/* {/block 'acceptButton'} */
}
