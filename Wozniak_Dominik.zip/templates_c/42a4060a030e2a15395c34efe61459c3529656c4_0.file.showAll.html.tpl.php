<?php
/* Smarty version 3.1.33, created on 2018-12-12 16:24:51
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\ZawodnikMecz\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c112843916410_06957210',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '42a4060a030e2a15395c34efe61459c3529656c4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\ZawodnikMecz\\showAll.html.tpl',
      1 => 1544628285,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c112843916410_06957210 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5004991745c1128438e1627_02565188', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15063410565c1128438e3424_85842367', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7156247465c1128438fc402_93456356', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1972045635c1128439002f8_03303164', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2108623695c112843901a37_65761189', 'tbody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_5004991745c1128438e1627_02565188 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_5004991745c1128438e1627_02565188',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista występów zawodników w meczach<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_17084798615c1128438e45c4_49755306 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnikmecz/formularz/" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Dodaj występ zawodnika w meczu">
        <span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span>
        Dodaj występ zawodnika w meczu
      </a>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_15063410565c1128438e3424_85842367 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_15063410565c1128438e3424_85842367',
  ),
  'groupAction' => 
  array (
    0 => 'Block_17084798615c1128438e45c4_49755306',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17084798615c1128438e45c4_49755306', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_7156247465c1128438fc402_93456356 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_7156247465c1128438fc402_93456356',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Data</th>
  <th>Mecz</th>
  <th>Zawodnik</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_1972045635c1128439002f8_03303164 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_1972045635c1128439002f8_03303164',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Data</th>
  <th class="searchable">Mecz</th>
  <th class="searchable">Zawodnik</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_2108623695c112843901a37_65761189 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_2108623695c112843901a37_65761189',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['Data'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['IdKlubGoscie']]['Nazwa'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['row']->value['IdZ']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['row']->value['IdZ']]['Nazwisko'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnikmecz/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnikmecz/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-danger btn-sm delete-button"
        data-toggle="tooltip" data-placement="top" title="Usuń">
        <span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span>
    </a>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
}
