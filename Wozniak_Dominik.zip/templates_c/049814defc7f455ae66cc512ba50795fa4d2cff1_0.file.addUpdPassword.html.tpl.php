<?php
/* Smarty version 3.1.33, created on 2019-01-21 22:17:41
  from 'C:\xampp\htdocs\projekt\templates\Access\addUpdPassword.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c4636f5203635_19025585',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '049814defc7f455ae66cc512ba50795fa4d2cff1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Access\\addUpdPassword.html.tpl',
      1 => 1548105060,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./passwordForm.html.tpl' => 1,
  ),
),false)) {
function content_5c4636f5203635_19025585 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20619629885c4636f51c5791_75821518', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20622020005c4636f51c7d59_11075647', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18811736645c4636f51c98b9_77808453', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_20619629885c4636f51c5791_75821518 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_20619629885c4636f51c5791_75821518',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Zmień hasło<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_20622020005c4636f51c7d59_11075647 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_20622020005c4636f51c7d59_11075647',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

user/zmien-haslo/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_18811736645c4636f51c98b9_77808453 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_18811736645c4636f51c98b9_77808453',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:./passwordForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
