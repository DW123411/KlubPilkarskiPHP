<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:20:12
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\addMecz.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d0eecabfe39_85844812',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '38466fa1667fe159df34ee195ddb1f23639a7723' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\addMecz.html.tpl',
      1 => 1546456806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Mecz/meczForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2d0eecabfe39_85844812 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19985857855c2d0eecab1ce7_26540976', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8237513015c2d0eecab3d63_08926319', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9738049505c2d0eecab5282_69012219', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2459551825c2d0eecabec84_66070952', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_19985857855c2d0eecab1ce7_26540976 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_19985857855c2d0eecab1ce7_26540976',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
mecz/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_8237513015c2d0eecab3d63_08926319 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_8237513015c2d0eecab3d63_08926319',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy mecz<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_9738049505c2d0eecab5282_69012219 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_9738049505c2d0eecab5282_69012219',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../Mecz/meczForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_2459551825c2d0eecabec84_66070952 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_2459551825c2d0eecabec84_66070952',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
