<?php
/* Smarty version 3.1.33, created on 2018-12-10 13:56:45
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Klub\addForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0e628d1399f0_97167764',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9b26ac01d2279260090399e0734e20e8d39852c5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Klub\\addForm.html.tpl',
      1 => 1544444511,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./klubForm.html.tpl' => 1,
  ),
),false)) {
function content_5c0e628d1399f0_97167764 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16002801245c0e628d0f6e17_91591898', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9884073775c0e628d0f8cf6_97337564', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15450587905c0e628d0fa964_96392645', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_16002801245c0e628d0f6e17_91591898 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_16002801245c0e628d0f6e17_91591898',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy klub<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_9884073775c0e628d0f8cf6_97337564 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_9884073775c0e628d0f8cf6_97337564',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

klub/dodaj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_15450587905c0e628d0fa964_96392645 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_15450587905c0e628d0fa964_96392645',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./klubForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
