<?php
/* Smarty version 3.1.33, created on 2018-12-06 13:57:33
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\baseTemplate.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c091cbd02a699_02855941',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e52c1fea0f83d4328955d49d10475f2d7f23b762' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\baseTemplate.html.tpl',
      1 => 1536075110,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./headerBlock.html.tpl' => 1,
    'file:./navbarBlock.html.tpl' => 1,
    'file:./bodyBlock.html.tpl' => 1,
    'file:./footerBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c091cbd02a699_02855941 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:./headerBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:./navbarBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:./bodyBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:./footerBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
