<?php
/* Smarty version 3.1.33, created on 2019-01-14 15:32:04
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editStadion.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3c9d646013a0_27533112',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a64e79c683a51fc2d6dc573d2ff441bfecc40189' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editStadion.html.tpl',
      1 => 1547476233,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Stadion/stadionForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3c9d646013a0_27533112 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2025398735c3c9d645cc884_94743507', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19596167425c3c9d645d04e4_82345911', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3914373775c3c9d645d2085_03972057', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19755374865c3c9d645ff6f6_33985031', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_2025398735c3c9d645cc884_94743507 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_2025398735c3c9d645cc884_94743507',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
stadion/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_19596167425c3c9d645d04e4_82345911 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_19596167425c3c9d645d04e4_82345911',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj stadion<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_3914373775c3c9d645d2085_03972057 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_3914373775c3c9d645d2085_03972057',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../Stadion/stadionForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_19755374865c3c9d645ff6f6_33985031 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_19755374865c3c9d645ff6f6_33985031',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
