<?php
/* Smarty version 3.1.33, created on 2018-12-12 15:50:20
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Trener\addForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c11202c886a67_87330732',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b8ce40dac0c454623797dbebf6b22022b57fa3dc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Trener\\addForm.html.tpl',
      1 => 1544626159,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./trenerForm.html.tpl' => 1,
  ),
),false)) {
function content_5c11202c886a67_87330732 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16576055205c11202c871fe2_99587767', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16373323055c11202c874641_61759973', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6120462635c11202c8762e3_79257303', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_16576055205c11202c871fe2_99587767 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_16576055205c11202c871fe2_99587767',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy trener<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_16373323055c11202c874641_61759973 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_16373323055c11202c874641_61759973',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

trener/dodaj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_6120462635c11202c8762e3_79257303 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_6120462635c11202c8762e3_79257303',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./trenerForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
