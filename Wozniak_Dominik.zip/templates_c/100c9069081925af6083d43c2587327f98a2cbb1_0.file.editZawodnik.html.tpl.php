<?php
/* Smarty version 3.1.33, created on 2019-01-12 17:51:43
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editZawodnik.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3a1b1fc8cd21_61462449',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '100c9069081925af6083d43c2587327f98a2cbb1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editZawodnik.html.tpl',
      1 => 1547311894,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Zawodnik/zawodnikForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3a1b1fc8cd21_61462449 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20653028145c3a1b1fc67f32_87510584', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17429547825c3a1b1fc69d94_11757550', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2953900555c3a1b1fc6b5d7_61907557', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4914760435c3a1b1fc8bb55_71793245', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_20653028145c3a1b1fc67f32_87510584 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_20653028145c3a1b1fc67f32_87510584',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
zawodnik/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_17429547825c3a1b1fc69d94_11757550 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_17429547825c3a1b1fc69d94_11757550',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj zawodnika<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_2953900555c3a1b1fc6b5d7_61907557 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_2953900555c3a1b1fc6b5d7_61907557',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../Zawodnik/zawodnikForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_4914760435c3a1b1fc8bb55_71793245 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_4914760435c3a1b1fc8bb55_71793245',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
