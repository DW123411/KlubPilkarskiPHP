<?php
/* Smarty version 3.1.33, created on 2019-01-16 16:19:35
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\notAllow.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f4b8733a0a0_95142629',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ace5e695436fcea854a5ac13ee6a1bea3263aea4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\notAllow.html.tpl',
      1 => 1539012702,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c3f4b8733a0a0_95142629 (Smarty_Internal_Template $_smarty_tpl) {
?>BRAK DOSTĘPU
<?php }
}
