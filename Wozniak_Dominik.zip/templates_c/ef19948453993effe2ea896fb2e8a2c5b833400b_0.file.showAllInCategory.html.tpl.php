<?php
/* Smarty version 3.1.33, created on 2019-01-16 19:24:30
  from 'C:\xampp\htdocs\projekt\templates\Mecz\showAllInCategory.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f76deb5eaa9_37036799',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ef19948453993effe2ea896fb2e8a2c5b833400b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Mecz\\showAllInCategory.html.tpl',
      1 => 1547663064,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c3f76deb5eaa9_37036799 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10874054165c3f76deb3bec4_66816681', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12555329705c3f76deb524f7_22650579', 'groupAction');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./showAll.html.tpl");
}
/* {block 'title'} */
class Block_10874054165c3f76deb3bec4_66816681 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_10874054165c3f76deb3bec4_66816681',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista meczy w sezonie: <?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokDo'];
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_12555329705c3f76deb524f7_22650579 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'groupAction' => 
  array (
    0 => 'Block_12555329705c3f76deb524f7_22650579',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<button type="button" class="btn btn-primary add-button"
        data-url="mecz/formularz/"
        data-toggle="tooltip" data-placement="top" title="Dodaj mecz">
        <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj mecz
</button>
<a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/tabela/<?php echo $_smarty_tpl->tpl_vars['selectedSeason']->value;?>
/" type="button" class="btn btn-info"
        data-toggle="tooltip" data-placement="top" title="Wyświetl tabelę ligową">
 	<span class="glyphicon glyphicon glyphicon-th-list" aria-hidden="true"></span>
    Tabela ligowa
 </a>
 <?php
}
}
/* {/block 'groupAction'} */
}
