<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:16:31
  from 'C:\xampp\htdocs\projekt\templates\Mecz\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f58df4898d7_86373814',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d617106db4c0495a6e37d36ed356df42475e122' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Mecz\\showOne.html.tpl',
      1 => 1547655381,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f58df4898d7_86373814 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12601249475c3f58df44e846_85103058', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9717850735c3f58df4510a8_59567809', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16544590055c3f58df47f386_95160523', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_12601249475c3f58df44e846_85103058 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_12601249475c3f58df44e846_85103058',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o meczu<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_9717850735c3f58df4510a8_59567809 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_9717850735c3f58df4510a8_59567809',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['data']->value['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['data']->value['IdKlubGoscie']]['Nazwa'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['BramkiGospodarze'];?>
:<?php echo $_smarty_tpl->tpl_vars['data']->value['BramkiGoscie'];?>
</h3>
        <p>Sezon: <?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['data']->value['IdS']]['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['data']->value['IdS']]['RokDo'];?>
</p>
        <p>Data: <?php echo $_smarty_tpl->tpl_vars['data']->value['Data'];?>
</p>
        <p>Stadion: <?php echo $_smarty_tpl->tpl_vars['stadiums']->value[$_smarty_tpl->tpl_vars['data']->value['IdStadion']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['stadiums']->value[$_smarty_tpl->tpl_vars['data']->value['IdStadion']]['Miejscowosc'];?>
</p>
        <p>Punkty gospodarzy: <?php echo $_smarty_tpl->tpl_vars['data']->value['PunktyGospodarze'];?>
</p>
        <p>Punkty gości: <?php echo $_smarty_tpl->tpl_vars['data']->value['PunktyGoscie'];?>
</p>
        <p>Opis: <?php echo $_smarty_tpl->tpl_vars['data']->value['Opis'];?>
</p>
        <p>Sędzia: <?php echo $_smarty_tpl->tpl_vars['referees']->value[$_smarty_tpl->tpl_vars['data']->value['IdSedzia']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['referees']->value[$_smarty_tpl->tpl_vars['data']->value['IdSedzia']]['Nazwisko'];?>
</p>
        <p>Ilość kibiców: <?php echo $_smarty_tpl->tpl_vars['data']->value['Kibice'];?>
</p>
        <p class="text-right">
          <button type="button" class="btn btn-warning edit-button"
              data-url="mecz/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"
              data-toggle="tooltip" data-placement="top" title="Modyfikuj mecz">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Modyfikuj mecz
          </button>
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="mecz/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['data']->value['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['data']->value['IdKlubGoscie']]['Nazwa'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń mecz">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń mecz
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_16544590055c3f58df47f386_95160523 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_16544590055c3f58df47f386_95160523',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
