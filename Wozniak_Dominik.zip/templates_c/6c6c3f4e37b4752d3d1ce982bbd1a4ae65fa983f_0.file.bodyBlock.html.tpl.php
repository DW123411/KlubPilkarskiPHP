<?php
/* Smarty version 3.1.33, created on 2019-01-02 14:17:03
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\bodyBlock.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2cb9cf03cb15_27782305',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6c6c3f4e37b4752d3d1ce982bbd1a4ae65fa983f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\bodyBlock.html.tpl',
      1 => 1546434944,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./flashMessage.html.tpl' => 1,
    'file:./modals/base.html.tpl' => 1,
  ),
),false)) {
function content_5c2cb9cf03cb15_27782305 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<div class="container">
  <div class="page-header">
    <h1><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18575559725c2cb9cf0388d4_31609825', 'title');
?>
</h1>
  </div>
  <?php $_smarty_tpl->_subTemplateRender('file:./flashMessage.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17122629575c2cb9cf03ae58_78519490', 'body');
?>

</div>
<?php $_smarty_tpl->_subTemplateRender('file:./modals/base.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
/* {block 'title'} */
class Block_18575559725c2cb9cf0388d4_31609825 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_18575559725c2cb9cf0388d4_31609825',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Przykładowy tytuł strony<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_17122629575c2cb9cf03ae58_78519490 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_17122629575c2cb9cf03ae58_78519490',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php
}
}
/* {/block 'body'} */
}
