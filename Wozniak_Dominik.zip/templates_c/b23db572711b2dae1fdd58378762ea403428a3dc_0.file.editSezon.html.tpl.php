<?php
/* Smarty version 3.1.33, created on 2019-01-14 13:50:51
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editSezon.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3c85ab5511f9_72738957',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b23db572711b2dae1fdd58378762ea403428a3dc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editSezon.html.tpl',
      1 => 1547470202,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Sezon/sezonForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3c85ab5511f9_72738957 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3249208565c3c85ab52c7a0_76082427', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3387647645c3c85ab52ef90_30457345', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4512672895c3c85ab530605_29889185', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7175558485c3c85ab54ff80_70811628', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_3249208565c3c85ab52c7a0_76082427 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_3249208565c3c85ab52c7a0_76082427',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
sezon/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_3387647645c3c85ab52ef90_30457345 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_3387647645c3c85ab52ef90_30457345',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj sezon<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_4512672895c3c85ab530605_29889185 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_4512672895c3c85ab530605_29889185',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../Sezon/sezonForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_7175558485c3c85ab54ff80_70811628 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_7175558485c3c85ab54ff80_70811628',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
