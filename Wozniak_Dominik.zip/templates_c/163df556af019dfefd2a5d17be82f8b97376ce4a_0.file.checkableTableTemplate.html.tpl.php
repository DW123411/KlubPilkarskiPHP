<?php
/* Smarty version 3.1.33, created on 2018-12-10 13:32:02
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\checkableTableTemplate.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0e5cc2f16096_00584573',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '163df556af019dfefd2a5d17be82f8b97376ce4a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\checkableTableTemplate.html.tpl',
      1 => 1537972690,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c0e5cc2f16096_00584573 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16006460905c0e5cc2f0bac7_31396808', 'checkableFormHeader');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4723179355c0e5cc2f150d4_11459133', 'checkableFormFooter');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./tableTemplate.html.tpl");
}
/* {block 'action'} */
class Block_13435048575c0e5cc2f0fcb4_40218647 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'action'} */
/* {block 'submit'} */
class Block_18223307795c0e5cc2f12ac7_75970118 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń zaznaczone<?php
}
}
/* {/block 'submit'} */
/* {block 'groupAction'} */
class Block_14772153605c0e5cc2f11a20_76857145 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<button type="submit" class="btn btn-danger pull-right" title="Usuń zaznaczone">
			<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18223307795c0e5cc2f12ac7_75970118', 'submit', $this->tplIndex);
?>

		</button>
	<?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_16006460905c0e5cc2f0bac7_31396808 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_16006460905c0e5cc2f0bac7_31396808',
  ),
  'action' => 
  array (
    0 => 'Block_13435048575c0e5cc2f0fcb4_40218647',
  ),
  'groupAction' => 
  array (
    0 => 'Block_14772153605c0e5cc2f11a20_76857145',
  ),
  'submit' => 
  array (
    0 => 'Block_18223307795c0e5cc2f12ac7_75970118',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form id="form-datatable" class="checkable" action="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13435048575c0e5cc2f0fcb4_40218647', 'action', $this->tplIndex);
?>
" method="POST">
<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14772153605c0e5cc2f11a20_76857145', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'checkableFormFooter'} */
class Block_4723179355c0e5cc2f150d4_11459133 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormFooter' => 
  array (
    0 => 'Block_4723179355c0e5cc2f150d4_11459133',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

</form>
<?php
}
}
/* {/block 'checkableFormFooter'} */
}
