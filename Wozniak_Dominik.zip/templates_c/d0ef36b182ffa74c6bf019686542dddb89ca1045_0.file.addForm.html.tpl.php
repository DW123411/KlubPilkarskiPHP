<?php
/* Smarty version 3.1.33, created on 2018-12-11 13:21:17
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Sedzia\addForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0fabbd5b6cd4_76493972',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd0ef36b182ffa74c6bf019686542dddb89ca1045' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Sedzia\\addForm.html.tpl',
      1 => 1544530778,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./sedziaForm.html.tpl' => 1,
  ),
),false)) {
function content_5c0fabbd5b6cd4_76493972 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17927291005c0fabbd5aa124_56223792', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19287868595c0fabbd5ac090_11809455', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11925112525c0fabbd5ad623_76180626', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_17927291005c0fabbd5aa124_56223792 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_17927291005c0fabbd5aa124_56223792',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy sędzia<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_19287868595c0fabbd5ac090_11809455 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_19287868595c0fabbd5ac090_11809455',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

sedzia/dodaj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_11925112525c0fabbd5ad623_76180626 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_11925112525c0fabbd5ad623_76180626',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./sedziaForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
