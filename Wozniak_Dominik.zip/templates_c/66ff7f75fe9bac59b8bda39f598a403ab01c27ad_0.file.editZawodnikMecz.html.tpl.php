<?php
/* Smarty version 3.1.33, created on 2019-01-14 15:57:27
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editZawodnikMecz.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3ca35761e934_37481973',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '66ff7f75fe9bac59b8bda39f598a403ab01c27ad' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editZawodnikMecz.html.tpl',
      1 => 1547477750,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../ZawodnikMecz/zawodnikmeczForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3ca35761e934_37481973 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14303820115c3ca3575f6b99_79896331', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2997268055c3ca3575f9004_02749624', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6019272635c3ca3575fa8f4_46650208', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3358572405c3ca35761d473_86794386', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_14303820115c3ca3575f6b99_79896331 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_14303820115c3ca3575f6b99_79896331',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
zawodnikmecz/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_2997268055c3ca3575f9004_02749624 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_2997268055c3ca3575f9004_02749624',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj występ zawodnika w meczu<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_6019272635c3ca3575fa8f4_46650208 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_6019272635c3ca3575fa8f4_46650208',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../ZawodnikMecz/zawodnikmeczForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_3358572405c3ca35761d473_86794386 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_3358572405c3ca35761d473_86794386',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
