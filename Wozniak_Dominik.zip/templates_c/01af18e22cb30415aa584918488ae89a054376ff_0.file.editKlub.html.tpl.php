<?php
/* Smarty version 3.1.33, created on 2019-01-14 12:41:34
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editKlub.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3c756e7a0ca6_87737627',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '01af18e22cb30415aa584918488ae89a054376ff' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editKlub.html.tpl',
      1 => 1547466038,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Klub/klubForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3c756e7a0ca6_87737627 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13306992275c3c756e77aaa6_18414463', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11201013115c3c756e77ca30_26969813', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20328251385c3c756e77e086_91903772', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18104881975c3c756e79fa27_20779268', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_13306992275c3c756e77aaa6_18414463 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_13306992275c3c756e77aaa6_18414463',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
klub/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_11201013115c3c756e77ca30_26969813 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_11201013115c3c756e77ca30_26969813',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj klub<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_20328251385c3c756e77e086_91903772 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_20328251385c3c756e77e086_91903772',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../Klub/klubForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_18104881975c3c756e79fa27_20779268 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_18104881975c3c756e79fa27_20779268',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
