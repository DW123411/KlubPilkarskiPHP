<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:37:15
  from 'C:\xampp\htdocs\projekt\templates\ZawodnikMecz\zawodnikmeczForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d12eb3289e2_31240016',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c82a2e5605df0435409f67663c8c4202eb380542' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ZawodnikMecz\\zawodnikmeczForm.html.tpl',
      1 => 1546369426,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2d12eb3289e2_31240016 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\projekt\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="form-group">
  <label for="idm">Mecz</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdM'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idm','options'=>$_smarty_tpl->tpl_vars['matches']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdM']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idm','options'=>$_smarty_tpl->tpl_vars['matches']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idz">Zawodnik</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdZ'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idz','options'=>$_smarty_tpl->tpl_vars['players']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdZ']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idz','options'=>$_smarty_tpl->tpl_vars['players']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="pozycja">Pozycja</label>
  <input class="form-control" id="pozycja" name="pozycja" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Pozycja'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Pozycja'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="3"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="minutyod">Minuty od</label>
  <input class="form-control" id="minutyod" name="minutyod" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['MinutyOd'])) {
echo $_smarty_tpl->tpl_vars['data']->value['MinutyOd'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="3"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="minutydo">Minuty do</label>
  <input class="form-control" id="minutydo" name="minutydo" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['MinutyDo'])) {
echo $_smarty_tpl->tpl_vars['data']->value['MinutyDo'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="3"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="bramki">Bramki</label>
  <input class="form-control" id="bramki" name="bramki" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Bramki'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Bramki'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="2"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="asysty">Asysty</label>
  <input class="form-control" id="asysty" name="asysty" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Asysty'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Asysty'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="2"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="kartkizolte">Kartki żółte</label>
  <input class="form-control" id="kartkizolte" name="kartkizolte" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['KartkiZolte'])) {
echo $_smarty_tpl->tpl_vars['data']->value['KartkiZolte'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="1"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="kartkiczerwone">Kartki czerwone</label>
  <input class="form-control" id="kartkiczerwone" name="kartkiczerwone" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['KartkiCzerwone'])) {
echo $_smarty_tpl->tpl_vars['data']->value['KartkiCzerwone'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="1"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="podaniaudane">Podania udane</label>
  <input class="form-control" id="podaniaudane" name="podaniaudane" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['PodaniaUdane'])) {
echo $_smarty_tpl->tpl_vars['data']->value['PodaniaUdane'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="3"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="podanianieudane">Podania nieudane</label>
  <input class="form-control" id="podanianieudane" name="podanianieudane" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['PodaniaNieudane'])) {
echo $_smarty_tpl->tpl_vars['data']->value['PodaniaNieudane'];
}?>"
    type="text"
    data-minlength="1"
    maxlength="3"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 1 znak"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<?php }
}
