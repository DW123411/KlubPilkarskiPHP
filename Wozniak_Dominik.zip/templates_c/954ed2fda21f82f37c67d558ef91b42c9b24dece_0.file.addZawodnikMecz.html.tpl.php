<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:37:15
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\addZawodnikMecz.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d12eb27cdb7_32849454',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '954ed2fda21f82f37c67d558ef91b42c9b24dece' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\addZawodnikMecz.html.tpl',
      1 => 1546457792,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../ZawodnikMecz/zawodnikmeczForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2d12eb27cdb7_32849454 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13287824775c2d12eb26bd40_45174394', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10322447205c2d12eb26e257_32361865', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4672815075c2d12eb26fa43_72877899', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12356005555c2d12eb27b879_81458462', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_13287824775c2d12eb26bd40_45174394 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_13287824775c2d12eb26bd40_45174394',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
zawodnikmecz/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_10322447205c2d12eb26e257_32361865 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_10322447205c2d12eb26e257_32361865',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy występ zawodnika w meczu<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_4672815075c2d12eb26fa43_72877899 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_4672815075c2d12eb26fa43_72877899',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../ZawodnikMecz/zawodnikmeczForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_12356005555c2d12eb27b879_81458462 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_12356005555c2d12eb27b879_81458462',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
