<?php
/* Smarty version 3.1.33, created on 2019-01-23 16:11:26
  from 'C:\xampp\htdocs\projekt\templates\checkableTableTemplate.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c48841e38b101_87717833',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '26ad5efa82b0292d92824584e56ac6be22aabea5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\checkableTableTemplate.html.tpl',
      1 => 1548256283,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c48841e38b101_87717833 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15920501085c48841e3730a4_63369567', 'checkableFormHeader');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16049613655c48841e38a0e6_70778407', 'checkableFormFooter');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./tableTemplate.html.tpl");
}
/* {block 'action'} */
class Block_19607131135c48841e385755_77326492 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'action'} */
/* {block 'submit'} */
class Block_2958066435c48841e387b43_02212368 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Transferuj zaznaczone<?php
}
}
/* {/block 'submit'} */
/* {block 'groupAction'} */
class Block_2215491365c48841e386e00_37016857 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<button type="submit" class="btn btn-warning pull-right edit-button" title="Transferuj zaznaczone">
			<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2958066435c48841e387b43_02212368', 'submit', $this->tplIndex);
?>

		</button>
	<?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_15920501085c48841e3730a4_63369567 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_15920501085c48841e3730a4_63369567',
  ),
  'action' => 
  array (
    0 => 'Block_19607131135c48841e385755_77326492',
  ),
  'groupAction' => 
  array (
    0 => 'Block_2215491365c48841e386e00_37016857',
  ),
  'submit' => 
  array (
    0 => 'Block_2958066435c48841e387b43_02212368',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form id="form-datatable" class="checkable" action="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19607131135c48841e385755_77326492', 'action', $this->tplIndex);
?>
" method="POST">
<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2215491365c48841e386e00_37016857', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'checkableFormFooter'} */
class Block_16049613655c48841e38a0e6_70778407 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormFooter' => 
  array (
    0 => 'Block_16049613655c48841e38a0e6_70778407',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

</form>
<?php
}
}
/* {/block 'checkableFormFooter'} */
}
