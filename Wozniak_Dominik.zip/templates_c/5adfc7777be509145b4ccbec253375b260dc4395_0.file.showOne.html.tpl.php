<?php
/* Smarty version 3.1.33, created on 2018-12-11 12:54:37
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Mecz\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0fa57d6904b9_66075838',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5adfc7777be509145b4ccbec253375b260dc4395' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Mecz\\showOne.html.tpl',
      1 => 1544529208,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c0fa57d6904b9_66075838 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_21309712745c0fa57d65be56_38119473', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11996853335c0fa57d65dce0_49980850', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15960662695c0fa57d68f276_94719454', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_21309712745c0fa57d65be56_38119473 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_21309712745c0fa57d65be56_38119473',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o meczu<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_11996853335c0fa57d65dce0_49980850 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_11996853335c0fa57d65dce0_49980850',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['data']->value['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['data']->value['IdKlubGoscie']]['Nazwa'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['BramkiGospodarze'];?>
:<?php echo $_smarty_tpl->tpl_vars['data']->value['BramkiGoscie'];?>
</h3>
        <p>Sezon: <?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['data']->value['IdS']]['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['data']->value['IdS']]['RokDo'];?>
</p>
        <p>Data: <?php echo $_smarty_tpl->tpl_vars['data']->value['Data'];?>
</p>
        <p>Stadion: <?php echo $_smarty_tpl->tpl_vars['stadiums']->value[$_smarty_tpl->tpl_vars['data']->value['IdStadion']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['stadiums']->value[$_smarty_tpl->tpl_vars['data']->value['IdStadion']]['Miejscowosc'];?>
</p>
        <p>Punkty gospodarzy: <?php echo $_smarty_tpl->tpl_vars['data']->value['PunktyGospodarze'];?>
</p>
        <p>Punkty gości: <?php echo $_smarty_tpl->tpl_vars['data']->value['PunktyGoscie'];?>
</p>
        <p>Opis: <?php echo $_smarty_tpl->tpl_vars['data']->value['Opis'];?>
</p>
        <p>Sędzia: <?php echo $_smarty_tpl->tpl_vars['referees']->value[$_smarty_tpl->tpl_vars['data']->value['IdSedzia']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['referees']->value[$_smarty_tpl->tpl_vars['data']->value['IdSedzia']]['Nazwisko'];?>
</p>
        <p>Ilość kibiców: <?php echo $_smarty_tpl->tpl_vars['data']->value['Kibice'];?>
</p>
        <p class="text-right">
          <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" type="button" class="btn btn-danger btn-sm delete-button"
              data-toggle="tooltip" data-placement="top" title="Usuń">
              <span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń mecz
          </a>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_15960662695c0fa57d68f276_94719454 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_15960662695c0fa57d68f276_94719454',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'footer'} */
}
