<?php
/* Smarty version 3.1.33, created on 2019-01-23 21:36:25
  from 'C:\xampp\htdocs\projekt\templates\Zawodnik\showStatistics.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c48d049f3b339_62250490',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6ba72476cc5c4042183650cbe0e289c11b92bf31' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Zawodnik\\showStatistics.html.tpl',
      1 => 1548275772,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c48d049f3b339_62250490 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18957878565c48d049eea942_88407842', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9836899455c48d049eec7a5_55708998', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12058623085c48d049f32216_71790850', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_18957878565c48d049eea942_88407842 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_18957878565c48d049eea942_88407842',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Statystyki zawodnika<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_9836899455c48d049eec7a5_55708998 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_9836899455c48d049eec7a5_55708998',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <?php if (isset($_smarty_tpl->tpl_vars['data']->value[0]['Imie'])) {?>
        <h3><?php echo $_smarty_tpl->tpl_vars['data']->value[0]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value[0]['Nazwisko'];?>
</h3>
        <p>Klub: <?php echo $_smarty_tpl->tpl_vars['data']->value[0]['Klub'];?>
</p>
        <p>Suma bramek: <?php echo $_smarty_tpl->tpl_vars['data']->value[0]['SumaBramek'];?>
</p>
        <p>Suma asyst: <?php echo $_smarty_tpl->tpl_vars['data']->value[0]['SumaAsyst'];?>
</p>
        <p>Procent udanych podań: <?php echo number_format((($_smarty_tpl->tpl_vars['data']->value[0]['SumaPodanUdanych']/($_smarty_tpl->tpl_vars['data']->value[0]['SumaPodanNieudanych']+$_smarty_tpl->tpl_vars['data']->value[0]['SumaPodanUdanych']))*100),2,'.',',');?>
%</p>
        <p>Suma żółtych kartek: <?php echo $_smarty_tpl->tpl_vars['data']->value[0]['SumaKartekZoltych'];?>
</p>
        <p>Suma czerwonych kartek: <?php echo $_smarty_tpl->tpl_vars['data']->value[0]['SumaKartekCzerwonych'];?>
</p>
        <p class="text-right">
        </p>
        <?php } else { ?>
          <h3>Brak danych</h3>
        <?php }?>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_12058623085c48d049f32216_71790850 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_12058623085c48d049f32216_71790850',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
