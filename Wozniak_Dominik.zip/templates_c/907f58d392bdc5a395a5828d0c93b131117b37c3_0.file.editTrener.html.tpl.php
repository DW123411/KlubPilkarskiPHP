<?php
/* Smarty version 3.1.33, created on 2019-01-14 15:41:21
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editTrener.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3c9f917efef1_38110724',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '907f58d392bdc5a395a5828d0c93b131117b37c3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editTrener.html.tpl',
      1 => 1547476821,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Trener/trenerForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3c9f917efef1_38110724 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15514461575c3c9f917aa695_38113315', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1146109805c3c9f917acc20_02735236', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_733717925c3c9f917ae698_83401059', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6872983635c3c9f917ee899_95554519', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_15514461575c3c9f917aa695_38113315 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_15514461575c3c9f917aa695_38113315',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
trener/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_1146109805c3c9f917acc20_02735236 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1146109805c3c9f917acc20_02735236',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj trenera<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_733717925c3c9f917ae698_83401059 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_733717925c3c9f917ae698_83401059',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../Trener/trenerForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_6872983635c3c9f917ee899_95554519 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_6872983635c3c9f917ee899_95554519',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
