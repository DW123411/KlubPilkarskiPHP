<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:26:37
  from 'C:\xampp\htdocs\projekt\templates\Stadion\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5b3d981378_32935161',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4b39b1cfe0d853e4828e0494cdd31f8fe6843b44' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Stadion\\showAll.html.tpl',
      1 => 1547655655,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5b3d981378_32935161 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17393372285c3f5b3d94ab67_55202239', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18116764165c3f5b3d94c979_74354828', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_563078075c3f5b3d94f981_54962898', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18523673905c3f5b3d950ea0_99104170', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12560481565c3f5b3d952a75_82101689', 'tbody');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11110779745c3f5b3d977331_89882854', 'footer');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_17393372285c3f5b3d94ab67_55202239 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_17393372285c3f5b3d94ab67_55202239',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista stadionów<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_6454632255c3f5b3d94dc36_25258643 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <button type="button" class="btn btn-primary add-button"
            data-url="stadion/formularz/"
            data-toggle="tooltip" data-placement="top" title="Dodaj stadion">
            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj stadion
      </button>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_18116764165c3f5b3d94c979_74354828 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_18116764165c3f5b3d94c979_74354828',
  ),
  'groupAction' => 
  array (
    0 => 'Block_6454632255c3f5b3d94dc36_25258643',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6454632255c3f5b3d94dc36_25258643', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_563078075c3f5b3d94f981_54962898 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_563078075c3f5b3d94f981_54962898',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Miejscowość</th>
  <th>Nazwa</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_18523673905c3f5b3d950ea0_99104170 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_18523673905c3f5b3d950ea0_99104170',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Miejscowość</th>
  <th class="searchable">Nazwa</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_12560481565c3f5b3d952a75_82101689 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_12560481565c3f5b3d952a75_82101689',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Miejscowosc'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Nazwa'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
stadion/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <button type="button" class="btn btn-danger btn-sm delete-button"
          data-url="stadion/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
/"
          data-description="<?php echo $_smarty_tpl->tpl_vars['row']->value['Miejscowosc'];?>
 - <?php echo $_smarty_tpl->tpl_vars['row']->value['Nazwa'];?>
"
          data-toggle="tooltip" data-placement="top" title="Usuń stadion">
          <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
    </button>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
/* {block 'footer'} */
class Block_11110779745c3f5b3d977331_89882854 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_11110779745c3f5b3d977331_89882854',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
