<?php
/* Smarty version 3.1.33, created on 2019-01-21 21:47:04
  from 'C:\xampp\htdocs\projekt\templates\Access\addUpd.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c462fc8bfa339_30788386',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3553fb210dff5edc394ad273f37d534c1c247fc0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Access\\addUpd.html.tpl',
      1 => 1548103620,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./userForm.html.tpl' => 1,
  ),
),false)) {
function content_5c462fc8bfa339_30788386 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4019141385c462fc8bd1a66_26168939', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6377515375c462fc8bd38f2_38685832', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2601398295c462fc8bd4e87_08241002', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_4019141385c462fc8bd1a66_26168939 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_4019141385c462fc8bd1a66_26168939',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Edytuj profil<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_6377515375c462fc8bd38f2_38685832 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_6377515375c462fc8bd38f2_38685832',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

user/modyfikuj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_2601398295c462fc8bd4e87_08241002 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_2601398295c462fc8bd4e87_08241002',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:./userForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
