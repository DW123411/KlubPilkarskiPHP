<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:26:22
  from 'C:\xampp\htdocs\projekt\templates\Sezon\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5b2eb30805_19134282',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b4f7a74bfc5950e98a69e679d1d080729149c26b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Sezon\\showAll.html.tpl',
      1 => 1547655980,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5b2eb30805_19134282 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5068667665c3f5b2eaeb0a5_21172973', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9906323625c3f5b2eaed663_55905824', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11415830445c3f5b2eaff607_60052888', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18897588875c3f5b2eb01019_09856781', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16244519325c3f5b2eb02928_19974774', 'tbody');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4259659375c3f5b2eb25927_74271999', 'footer');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_5068667665c3f5b2eaeb0a5_21172973 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_5068667665c3f5b2eaeb0a5_21172973',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista sezonów<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_4209017415c3f5b2eaeeed2_51673348 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <button type="button" class="btn btn-primary add-button"
            data-url="sezon/formularz/"
            data-toggle="tooltip" data-placement="top" title="Dodaj sezon">
            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj sezon
      </button>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_9906323625c3f5b2eaed663_55905824 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_9906323625c3f5b2eaed663_55905824',
  ),
  'groupAction' => 
  array (
    0 => 'Block_4209017415c3f5b2eaeeed2_51673348',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4209017415c3f5b2eaeeed2_51673348', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_11415830445c3f5b2eaff607_60052888 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_11415830445c3f5b2eaff607_60052888',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Id</th>
  <th>Sezon</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_18897588875c3f5b2eb01019_09856781 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_18897588875c3f5b2eb01019_09856781',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Id</th>
  <th class="searchable">Sezon</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_16244519325c3f5b2eb02928_19974774 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_16244519325c3f5b2eb02928_19974774',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['RokDo'];?>
</td>
  <td><span class="btn-group pull-right">
    <button type="button" class="btn btn-warning btn-sm edit-button"
          data-url="sezon/mod/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
"
          data-toggle="tooltip" data-placement="top" title="Modyfikuj sezon">
          <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
    </button>
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/sezon/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
/" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż wszystkie mecze w sezonie">
        <span class="glyphicon glyphicon-th-list" aria-hidden="true"></span>
    </a>
    <button type="button" class="btn btn-danger btn-sm delete-button"
          data-url="sezon/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
/"
          data-description="<?php echo $_smarty_tpl->tpl_vars['row']->value['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['RokDo'];?>
"
          data-toggle="tooltip" data-placement="top" title="Usuń sezon">
          <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
    </button>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
/* {block 'footer'} */
class Block_4259659375c3f5b2eb25927_74271999 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_4259659375c3f5b2eb25927_74271999',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
