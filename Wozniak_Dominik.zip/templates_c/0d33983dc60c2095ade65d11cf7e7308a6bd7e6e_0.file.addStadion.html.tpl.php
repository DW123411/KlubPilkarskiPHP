<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:30:57
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\addStadion.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d1171e456f3_64960428',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0d33983dc60c2095ade65d11cf7e7308a6bd7e6e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\addStadion.html.tpl',
      1 => 1546457418,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Stadion/stadionForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2d1171e456f3_64960428 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20417121885c2d1171dd9ae2_73068753', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12640783355c2d1171ddc180_94615153', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20865021145c2d1171dde052_52381484', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2751868365c2d1171e43fd4_51604395', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_20417121885c2d1171dd9ae2_73068753 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_20417121885c2d1171dd9ae2_73068753',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
stadion/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_12640783355c2d1171ddc180_94615153 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_12640783355c2d1171ddc180_94615153',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy stadion<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_20865021145c2d1171dde052_52381484 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_20865021145c2d1171dde052_52381484',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../Stadion/stadionForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_2751868365c2d1171e43fd4_51604395 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_2751868365c2d1171e43fd4_51604395',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
