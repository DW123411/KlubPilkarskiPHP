<?php
/* Smarty version 3.1.33, created on 2018-12-20 16:38:20
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Mecz\showLeagueTable.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c1bb76c22eac9_71629036',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0b3b1cf92f56d5e3ae0a735cf31406909e53246b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Mecz\\showLeagueTable.html.tpl',
      1 => 1545320296,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c1bb76c22eac9_71629036 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1526530255c1bb76c20abb7_96332388', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18693276785c1bb76c21fb15_55978516', 'groupAction');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14357044045c1bb76c2214a2_65892578', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9377480165c1bb76c223038_59821642', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19732438315c1bb76c224bf2_26676852', 'tbody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./showAll.html.tpl");
}
/* {block 'title'} */
class Block_1526530255c1bb76c20abb7_96332388 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1526530255c1bb76c20abb7_96332388',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Tabela ligowa <?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokDo'];
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_18693276785c1bb76c21fb15_55978516 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'groupAction' => 
  array (
    0 => 'Block_18693276785c1bb76c21fb15_55978516',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'groupAction'} */
/* {block 'thead'} */
class Block_14357044045c1bb76c2214a2_65892578 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_14357044045c1bb76c2214a2_65892578',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="hidden-print"></th>
  <th>Klub</th>
  <th>Punkty</th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_9377480165c1bb76c223038_59821642 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_9377480165c1bb76c223038_59821642',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th></th>
  <th class="searchable">Klub</th>
  <th>Punkty</th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_19732438315c1bb76c224bf2_26676852 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_19732438315c1bb76c224bf2_26676852',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td></td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Nazwa'];?>
</td>
  <td></td>
<?php
}
}
/* {/block 'tbody'} */
}
