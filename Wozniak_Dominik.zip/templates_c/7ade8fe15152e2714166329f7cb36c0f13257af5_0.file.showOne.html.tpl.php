<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:26:57
  from 'C:\xampp\htdocs\projekt\templates\Trener\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5b510a2e42_74337042',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7ade8fe15152e2714166329f7cb36c0f13257af5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Trener\\showOne.html.tpl',
      1 => 1547655727,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5b510a2e42_74337042 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13241383805c3f5b510851b8_28085331', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2869119955c3f5b51087114_68101041', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3732473705c3f5b510994d9_87722395', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_13241383805c3f5b510851b8_28085331 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_13241383805c3f5b510851b8_28085331',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o trenerze<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_2869119955c3f5b51087114_68101041 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_2869119955c3f5b51087114_68101041',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['data']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];?>
</h3>
        <p class="text-right">
          <button type="button" class="btn btn-warning edit-button"
              data-url="trener/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"
              data-toggle="tooltip" data-placement="top" title="Modyfikuj trenera">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Modyfikuj trenera
          </button>
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="trener/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['data']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń trenera">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń trenera
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_3732473705c3f5b510994d9_87722395 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_3732473705c3f5b510994d9_87722395',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
