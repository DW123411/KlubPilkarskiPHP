<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:20:12
  from 'C:\xampp\htdocs\projekt\templates\Mecz\meczForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d0eecb5d634_26181267',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39af210bdb805876eeccf33a9c8d0f8b91d6060f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Mecz\\meczForm.html.tpl',
      1 => 1546360951,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2d0eecb5d634_26181267 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\projekt\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="form-group">
  <label for="ids">Sezon</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdS'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'ids','options'=>$_smarty_tpl->tpl_vars['seasons']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdS']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'ids','options'=>$_smarty_tpl->tpl_vars['seasons']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="data">Data</label>
  <input class="form-control" id="data" name="data" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Data'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Data'];
}?>"
    type="text"
    maxlength="16"
    data-required-error="Pole wymagane"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idstadion">Stadion</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdStadion'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idstadion','options'=>$_smarty_tpl->tpl_vars['stadiums']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdStadion']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idstadion','options'=>$_smarty_tpl->tpl_vars['stadiums']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idklubgospodarze">Klub gospodarzy</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdKlubGospodarze'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idklubgospodarze','options'=>$_smarty_tpl->tpl_vars['clubs']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdKlubGospodarze']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idklubgospodarze','options'=>$_smarty_tpl->tpl_vars['clubs']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idklubgoscie">Klub gości</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdKlubGoscie'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idklubgoscie','options'=>$_smarty_tpl->tpl_vars['clubs']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdKlubGoscie']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idklubgoscie','options'=>$_smarty_tpl->tpl_vars['clubs']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="bramkigospodarze">Bramki gospodarzy</label>
  <input class="form-control" id="bramkigospodarze" name="bramkigospodarze" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['BramkiGospodarze'])) {
echo $_smarty_tpl->tpl_vars['data']->value['BramkiGospodarze'];
}?>"
    type="text"
    maxlength="50"
    data-required-error="Pole wymagane"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="bramkigoscie">Bramki gości</label>
  <input class="form-control" id="bramkigoscie" name="bramkigoscie" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['BramkiGoscie'])) {
echo $_smarty_tpl->tpl_vars['data']->value['BramkiGoscie'];
}?>"
    type="text"
    maxlength="50"
    data-required-error="Pole wymagane"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="punktygospodarze">Punkty gospodarzy</label>
  <input class="form-control" id="punktygospodarze" name="punktygospodarze" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['PunktyGospodarze'])) {
echo $_smarty_tpl->tpl_vars['data']->value['PunktyGospodarze'];
}?>"
    type="text"
    maxlength="50"
    data-required-error="Pole wymagane"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="punktygoscie">Punkty gości</label>
  <input class="form-control" id="punktygoscie" name="punktygoscie" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['PunktyGoscie'])) {
echo $_smarty_tpl->tpl_vars['data']->value['PunktyGoscie'];
}?>"
    type="text"
    maxlength="50"
    data-required-error="Pole wymagane"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="opis">Opis</label>
  <input class="form-control" id="opis" name="opis" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Opis'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Opis'];
}?>"
    type="text"
    maaxlength='100'>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idsedzia">Sędzia</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdSedzia'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idsedzia','options'=>$_smarty_tpl->tpl_vars['referees']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdSedzia']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idsedzia','options'=>$_smarty_tpl->tpl_vars['referees']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="kibice">Ilość kibiców</label>
  <input class="form-control" id="kibice" name="kibice" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Kibice'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Kibice'];
}?>"
    type="text"
    maxlength="50"
    data-required-error="Pole wymagane"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<?php }
}
