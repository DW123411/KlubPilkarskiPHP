<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:00:54
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\addZawodnik.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d0a667b4726_92609857',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '36fce513b33c46bfcbba952e9197fdb64434ab89' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\addZawodnik.html.tpl',
      1 => 1546434087,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Zawodnik/zawodnikForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2d0a667b4726_92609857 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4460798165c2d0a667a6244_88519711', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1385735345c2d0a667a8099_79781415', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18890072335c2d0a667a9926_10011969', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8644478185c2d0a667b3401_82130643', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_4460798165c2d0a667a6244_88519711 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_4460798165c2d0a667a6244_88519711',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
zawodnik/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_1385735345c2d0a667a8099_79781415 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1385735345c2d0a667a8099_79781415',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy zawodnik<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_18890072335c2d0a667a9926_10011969 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_18890072335c2d0a667a9926_10011969',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../Zawodnik/zawodnikForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_8644478185c2d0a667b3401_82130643 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_8644478185c2d0a667b3401_82130643',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
