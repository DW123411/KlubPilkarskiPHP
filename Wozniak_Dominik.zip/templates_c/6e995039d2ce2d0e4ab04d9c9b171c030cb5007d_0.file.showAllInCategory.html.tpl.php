<?php
/* Smarty version 3.1.33, created on 2018-12-20 16:01:14
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Mecz\showAllInCategory.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c1baeba3e2b02_24947368',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6e995039d2ce2d0e4ab04d9c9b171c030cb5007d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Mecz\\showAllInCategory.html.tpl',
      1 => 1545318072,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c1baeba3e2b02_24947368 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2922229325c1baeba3c20e8_08919979', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9275740165c1baeba3d6946_30143154', 'groupAction');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./showAll.html.tpl");
}
/* {block 'title'} */
class Block_2922229325c1baeba3c20e8_08919979 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_2922229325c1baeba3c20e8_08919979',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista meczy w sezonie: <?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokDo'];
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_9275740165c1baeba3d6946_30143154 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'groupAction' => 
  array (
    0 => 'Block_9275740165c1baeba3d6946_30143154',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/formularz/" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Dodaj mecz">
  	<span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span>
    Dodaj mecz
</a>
<a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/tabela/<?php echo $_smarty_tpl->tpl_vars['selectedSeason']->value;?>
/" type="button" class="btn btn-info btn-sm"
        data-toggle="tooltip" data-placement="top" title="Wyświetl tabelę ligową">
 	<span class="glyphicon glyphicon glyphicon-th-list" aria-hidden="true"></span>
    Tabela ligowa
 </a>
 <?php
}
}
/* {/block 'groupAction'} */
}
