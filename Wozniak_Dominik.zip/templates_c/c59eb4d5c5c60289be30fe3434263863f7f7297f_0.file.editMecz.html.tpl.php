<?php
/* Smarty version 3.1.33, created on 2019-01-14 13:14:59
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\editMecz.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3c7d43382026_94380771',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c59eb4d5c5c60289be30fe3434263863f7f7297f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\editMecz.html.tpl',
      1 => 1547467999,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Mecz/meczForm.html.tpl' => 1,
  ),
),false)) {
function content_5c3c7d43382026_94380771 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10747583335c3c7d43359f65_80967008', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20570222925c3c7d4335c376_62713084', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5339744635c3c7d4335de81_62239441', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7197325855c3c7d433809e8_03773333', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_10747583335c3c7d43359f65_80967008 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_10747583335c3c7d43359f65_80967008',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
mecz/modyfikuj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_20570222925c3c7d4335c376_62713084 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_20570222925c3c7d4335c376_62713084',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj mecz<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_5339744635c3c7d4335de81_62239441 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_5339744635c3c7d4335de81_62239441',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <input type="hidden" id="id" name="id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
  <?php $_smarty_tpl->_subTemplateRender("file:../Mecz/meczForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_7197325855c3c7d433809e8_03773333 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_7197325855c3c7d433809e8_03773333',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Modyfikuj</button><?php
}
}
/* {/block 'acceptButton'} */
}
