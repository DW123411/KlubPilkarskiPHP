<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:28:00
  from 'C:\xampp\htdocs\projekt\templates\Sezon\sezonForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d10c0850555_55990715',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a0d9efa14694d243ea4245b86b37715e51394c5b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Sezon\\sezonForm.html.tpl',
      1 => 1546368048,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2d10c0850555_55990715 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group has-feedback">
  <label for="rokod">Rok Od</label>
  <input class="form-control" id="rokod" name="rokod" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['RokOd'])) {
echo $_smarty_tpl->tpl_vars['data']->value['RokOd'];
}?>"
    type="text"
    data-minlength="4"
    maxlength="4"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 4 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="rokdo">Rok Do</label>
  <input class="form-control" id="rokdo" name="rokdo" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['RokDo'])) {
echo $_smarty_tpl->tpl_vars['data']->value['RokDo'];
}?>"
    type="text"
    data-minlength="4"
    maxlength="4"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 4 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<?php }
}
