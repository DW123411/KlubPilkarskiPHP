<?php
/* Smarty version 3.1.33, created on 2019-01-16 21:07:22
  from 'C:\xampp\htdocs\projekt\templates\Mecz\showLeagueTable.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f8efa6d79d0_33055051',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e2d82c7fb0358ffdf4a8c51e57e02e67aed8ec24' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Mecz\\showLeagueTable.html.tpl',
      1 => 1547669240,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c3f8efa6d79d0_33055051 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php $_smarty_tpl->_assignInScope('id', 1);?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12759733695c3f8efa6a7783_31251934', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4415633405c3f8efa6b6cc9_03314569', 'groupAction');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6574355005c3f8efa6b8089_02828088', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13796948065c3f8efa6b99b5_96877601', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3009252005c3f8efa6bba74_65107262', 'tbody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./showAll.html.tpl");
}
/* {block 'title'} */
class Block_12759733695c3f8efa6a7783_31251934 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_12759733695c3f8efa6a7783_31251934',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Tabela ligowa <?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['seasons']->value[$_smarty_tpl->tpl_vars['selectedSeason']->value]['RokDo'];
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_4415633405c3f8efa6b6cc9_03314569 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'groupAction' => 
  array (
    0 => 'Block_4415633405c3f8efa6b6cc9_03314569',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'groupAction'} */
/* {block 'thead'} */
class Block_6574355005c3f8efa6b8089_02828088 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_6574355005c3f8efa6b8089_02828088',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="hidden-print"></th>
  <th>Klub</th>
  <th>Punkty</th>
  <th>Bramki zdobyte/stracone</th>
  <th>Bilans bramkowy</th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_13796948065c3f8efa6b99b5_96877601 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_13796948065c3f8efa6b99b5_96877601',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th></th>
  <th class="searchable">Klub</th>
  <th>Punkty</th>
  <th>Bramki zdobyte/stracone</th>
  <th>Bilans bramkowy</th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_3009252005c3f8efa6bba74_65107262 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_3009252005c3f8efa6bba74_65107262',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['id']->value++;?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Klub'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Punkty'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['BramkiZdobyte'];?>
:<?php echo $_smarty_tpl->tpl_vars['row']->value['BramkiStracone'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['BilansBramkowy'];?>
</td>
<?php
}
}
/* {/block 'tbody'} */
}
