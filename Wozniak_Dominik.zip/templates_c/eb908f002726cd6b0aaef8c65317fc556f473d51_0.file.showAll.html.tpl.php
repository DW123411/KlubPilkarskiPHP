<?php
/* Smarty version 3.1.33, created on 2019-01-02 19:51:45
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Zawodnik\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d0841a41522_22512321',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eb908f002726cd6b0aaef8c65317fc556f473d51' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Zawodnik\\showAll.html.tpl',
      1 => 1546455102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2d0841a41522_22512321 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18960896305c2d0841a1aef0_64328101', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7699708445c2d0841a1cdb7_33223761', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2147674065c2d0841a20445_17938084', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2127417865c2d0841a21af3_93323877', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13977048295c2d0841a23547_23682313', 'tbody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_18960896305c2d0841a1aef0_64328101 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_18960896305c2d0841a1aef0_64328101',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista zawodników<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_16098605945c2d0841a1e079_61061110 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <button type="button" class="btn btn-primary add-button"
            data-url="zawodnik/formularz/"
            data-toggle="tooltip" data-placement="top" title="Dodaj zawodnika">
            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj zawodnika
      </button>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_7699708445c2d0841a1cdb7_33223761 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_7699708445c2d0841a1cdb7_33223761',
  ),
  'groupAction' => 
  array (
    0 => 'Block_16098605945c2d0841a1e079_61061110',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16098605945c2d0841a1e079_61061110', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_2147674065c2d0841a20445_17938084 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_2147674065c2d0841a20445_17938084',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Imie</th>
  <th>Nazwisko</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_2127417865c2d0841a21af3_93323877 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_2127417865c2d0841a21af3_93323877',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Imie</th>
  <th class="searchable">Nazwisko</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_13977048295c2d0841a23547_23682313 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_13977048295c2d0841a23547_23682313',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Imie'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Nazwisko'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnik/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnik/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-danger btn-sm delete-button"
        data-toggle="tooltip" data-placement="top" title="Usuń">
        <span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span>
    </a>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
}
