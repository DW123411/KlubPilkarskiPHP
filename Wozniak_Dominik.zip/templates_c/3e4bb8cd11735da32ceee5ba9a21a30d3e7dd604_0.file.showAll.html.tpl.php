<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:15:53
  from 'C:\xampp\htdocs\projekt\templates\Mecz\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f58b9537833_32492746',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3e4bb8cd11735da32ceee5ba9a21a30d3e7dd604' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Mecz\\showAll.html.tpl',
      1 => 1547655338,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f58b9537833_32492746 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1746465425c3f58b94fc002_72426505', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16094083645c3f58b94fde50_97550294', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8548022315c3f58b9500e37_61680927', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3160450275c3f58b95022f8_14534450', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19842049775c3f58b9503917_40474678', 'tbody');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18978791685c3f58b9529ab5_89447620', 'footer');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_1746465425c3f58b94fc002_72426505 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1746465425c3f58b94fc002_72426505',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista meczy<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_7620724225c3f58b94ff120_53219097 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <button type="button" class="btn btn-primary add-button"
            data-url="mecz/formularz/"
            data-toggle="tooltip" data-placement="top" title="Dodaj mecz">
            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj mecz
    </button>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_16094083645c3f58b94fde50_97550294 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_16094083645c3f58b94fde50_97550294',
  ),
  'groupAction' => 
  array (
    0 => 'Block_7620724225c3f58b94ff120_53219097',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7620724225c3f58b94ff120_53219097', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_8548022315c3f58b9500e37_61680927 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_8548022315c3f58b9500e37_61680927',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Data</th>
  <th>Mecz</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_3160450275c3f58b95022f8_14534450 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_3160450275c3f58b95022f8_14534450',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Data</th>
  <th class="searchable">Mecz</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_19842049775c3f58b9503917_40474678 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_19842049775c3f58b9503917_40474678',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Data'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['row']->value['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['row']->value['IdKlubGoscie']]['Nazwa'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <button type="button" class="btn btn-danger btn-sm delete-button"
          data-url="mecz/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
/"
          data-description="<?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['row']->value['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['row']->value['IdKlubGoscie']]['Nazwa'];?>
"
          data-toggle="tooltip" data-placement="top" title="Usuń mecz">
          <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
    </button>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
/* {block 'footer'} */
class Block_18978791685c3f58b9529ab5_89447620 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_18978791685c3f58b9529ab5_89447620',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
