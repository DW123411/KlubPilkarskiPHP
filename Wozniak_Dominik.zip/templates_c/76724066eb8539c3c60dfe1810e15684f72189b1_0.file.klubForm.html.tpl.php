<?php
/* Smarty version 3.1.33, created on 2019-01-14 12:52:06
  from 'C:\xampp\htdocs\projekt\templates\Klub\klubForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3c77e6151792_99229464',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '76724066eb8539c3c60dfe1810e15684f72189b1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Klub\\klubForm.html.tpl',
      1 => 1547466721,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c3c77e6151792_99229464 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\projekt\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="form-group has-feedback">
  <label for="siedziba">Siedziba</label>
  <input class="form-control" id="siedziba" name="siedziba" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Siedziba'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Siedziba'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="70"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="nazwa">Nazwa klubu</label>
  <input class="form-control" id="nazwa" name="nazwa" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Nazwa'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="90"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="opis">Opis</label>
  <input class="form-control" id="opis" name="opis" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Opis'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Opis'];
}?>"
    type="text"
    maaxlength='150'>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idt">Trener</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdT'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idt','options'=>$_smarty_tpl->tpl_vars['coaches']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdT']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idt','options'=>$_smarty_tpl->tpl_vars['coaches']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<?php }
}
