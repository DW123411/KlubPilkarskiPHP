<?php
/* Smarty version 3.1.33, created on 2018-12-11 12:47:48
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Mecz\addForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0fa3e4c0d5f2_77206177',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cdbf2d0c65825c1b7a1795090cc1f17e5b141e17' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Mecz\\addForm.html.tpl',
      1 => 1544528616,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./meczForm.html.tpl' => 1,
  ),
),false)) {
function content_5c0fa3e4c0d5f2_77206177 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12313030265c0fa3e4bff913_53092389', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15212301415c0fa3e4c01b56_09373341', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9455996045c0fa3e4c03161_36206666', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_12313030265c0fa3e4bff913_53092389 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_12313030265c0fa3e4bff913_53092389',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy mecz<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_15212301415c0fa3e4c01b56_09373341 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_15212301415c0fa3e4c01b56_09373341',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

mecz/dodaj/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_9455996045c0fa3e4c03161_36206666 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_9455996045c0fa3e4c03161_36206666',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./meczForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
