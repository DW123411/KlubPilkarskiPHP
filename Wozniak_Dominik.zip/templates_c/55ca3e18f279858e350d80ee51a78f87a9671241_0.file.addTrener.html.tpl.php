<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:34:09
  from 'C:\xampp\htdocs\projekt\templates\ajaxModals\addTrener.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d1231090ac8_12303416',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '55ca3e18f279858e350d80ee51a78f87a9671241' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ajaxModals\\addTrener.html.tpl',
      1 => 1546457603,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Trener/trenerForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2d1231090ac8_12303416 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19091896705c2d123107fc70_02166999', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10207787305c2d1231082081_63642659', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5755944245c2d1231083a40_42053366', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4239130105c2d123108f1c0_17450798', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_19091896705c2d123107fc70_02166999 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_19091896705c2d123107fc70_02166999',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
trener/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_10207787305c2d1231082081_63642659 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_10207787305c2d1231082081_63642659',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy trener<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_5755944245c2d1231083a40_42053366 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_5755944245c2d1231083a40_42053366',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../Trener/trenerForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_4239130105c2d123108f1c0_17450798 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_4239130105c2d123108f1c0_17450798',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
