<?php
/* Smarty version 3.1.33, created on 2019-01-17 14:09:28
  from 'C:\xampp\htdocs\projekt\templates\Zawodnik\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c407e88c492b0_50622019',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e1f7f85002e7c3c742a99437eadc09722ce0f2f4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Zawodnik\\showOne.html.tpl',
      1 => 1547730449,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c407e88c492b0_50622019 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4250125315c407e88c0eda6_12043776', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18875758575c407e88c10ea4_55848904', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4231453215c407e88c3f189_94912949', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_4250125315c407e88c0eda6_12043776 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_4250125315c407e88c0eda6_12043776',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o zawodniku<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_18875758575c407e88c10ea4_55848904 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_18875758575c407e88c10ea4_55848904',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['data']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];?>
</h3>
        <p>Klub: <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['data']->value['IdK']]['Nazwa'];?>
</p>
        <p>Opis: <?php echo $_smarty_tpl->tpl_vars['data']->value['Opis'];?>
</p>
        <p class="text-right">
          <button type="button" class="btn btn-warning edit-button"
            data-url="zawodnik/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"
            data-toggle="tooltip" data-placement="top" title="Modyfikuj zawodnika">
            <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Modyfikuj zawodnika
          </button>
          <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnik/statystyki/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
          data-toggle="tooltip" data-placement="top" title="Pokaż statystyki">
            <span class="glyphicon glyphicon glyphicon-italic" aria-hidden="true"></span>
          </a>
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="zawodnik/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['data']->value['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń zawodnika">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń zawodnika
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_4231453215c407e88c3f189_94912949 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_4231453215c407e88c3f189_94912949',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
