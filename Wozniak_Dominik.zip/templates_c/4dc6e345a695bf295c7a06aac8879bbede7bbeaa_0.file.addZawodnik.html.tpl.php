<?php
/* Smarty version 3.1.33, created on 2019-01-02 14:07:16
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\ajaxModals\addZawodnik.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2cb78450d6b4_49271457',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4dc6e345a695bf295c7a06aac8879bbede7bbeaa' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\ajaxModals\\addZawodnik.html.tpl',
      1 => 1546434087,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../Zawodnik/zawodnikForm.html.tpl' => 1,
  ),
),false)) {
function content_5c2cb78450d6b4_49271457 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16866892845c2cb7844e7fb6_39882786', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6924280865c2cb7844f2a65_39812337', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12572503775c2cb7844f6c15_90313188', 'body');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11552090675c2cb784509d74_28499515', 'acceptButton');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../modals/formBlock.html.tpl");
}
/* {block 'action'} */
class Block_16866892845c2cb7844e7fb6_39882786 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_16866892845c2cb7844e7fb6_39882786',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
zawodnik/dodaj/<?php
}
}
/* {/block 'action'} */
/* {block 'title'} */
class Block_6924280865c2cb7844f2a65_39812337 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_6924280865c2cb7844f2a65_39812337',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Nowy zawodnik<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_12572503775c2cb7844f6c15_90313188 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_12572503775c2cb7844f6c15_90313188',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../Zawodnik/zawodnikForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'body'} */
/* {block 'acceptButton'} */
class Block_11552090675c2cb784509d74_28499515 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'acceptButton' => 
  array (
    0 => 'Block_11552090675c2cb784509d74_28499515',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
<button type="submit" class="btn btn-success">Dodaj</button><?php
}
}
/* {/block 'acceptButton'} */
}
