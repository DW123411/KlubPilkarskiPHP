<?php
/* Smarty version 3.1.33, created on 2019-01-01 16:41:40
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Klub\klubForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2b8a349f9ce4_59613353',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '187c44dd8d928ddaf940afcba460d71b7ada018e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Klub\\klubForm.html.tpl',
      1 => 1546357235,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2b8a349f9ce4_59613353 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\ZPAI\\projekt\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="form-group has-feedback">
  <label for="siedziba">Siedziba</label>
  <input class="form-control" id="siedziba" name="siedziba" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['siedziba'])) {
echo $_smarty_tpl->tpl_vars['data']->value['siedziba'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="70"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="nazwa">Nazwa klubu</label>
  <input class="form-control" id="nazwa" name="nazwa" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['nazwa'])) {
echo $_smarty_tpl->tpl_vars['data']->value['nazwa'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="90"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="opis">Opis</label>
  <input class="form-control" id="opis" name="opis" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['opis'])) {
echo $_smarty_tpl->tpl_vars['data']->value['opis'];
}?>"
    type="text"
    maaxlength='150'>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group">
  <label for="idt">Trener</label>
  <?php if (isset($_smarty_tpl->tpl_vars['data']->value['IdT'])) {?>
    <?php echo smarty_function_html_options(array('name'=>'idt','options'=>$_smarty_tpl->tpl_vars['coaches']->value,'class'=>"form-control",'selected'=>$_smarty_tpl->tpl_vars['data']->value['IdT']),$_smarty_tpl);?>

  <?php } else { ?>
    <?php echo smarty_function_html_options(array('name'=>'idt','options'=>$_smarty_tpl->tpl_vars['coaches']->value,'class'=>"form-control"),$_smarty_tpl);?>

  <?php }?>

  <div class="help-block with-errors"></div>
</div>
<?php }
}
