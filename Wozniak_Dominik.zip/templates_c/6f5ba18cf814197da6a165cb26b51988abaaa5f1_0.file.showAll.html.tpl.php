<?php
/* Smarty version 3.1.33, created on 2018-12-11 13:28:36
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Sezon\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c0fad748b5937_22235622',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6f5ba18cf814197da6a165cb26b51988abaaa5f1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Sezon\\showAll.html.tpl',
      1 => 1544531281,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c0fad748b5937_22235622 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7899115875c0fad74883f09_94090363', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4181597945c0fad74885fc1_98823380', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12435704775c0fad7489cba7_92958774', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3574976375c0fad7489e3b5_43296911', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2970808725c0fad7489faf0_97884486', 'tbody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_7899115875c0fad74883f09_94090363 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_7899115875c0fad74883f09_94090363',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista sezonów<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_17612032065c0fad748873e0_60468843 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
sezon/formularz/" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Dodaj sezon">
        <span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span>
        Dodaj sezon
    </a>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_4181597945c0fad74885fc1_98823380 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_4181597945c0fad74885fc1_98823380',
  ),
  'groupAction' => 
  array (
    0 => 'Block_17612032065c0fad748873e0_60468843',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17612032065c0fad748873e0_60468843', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_12435704775c0fad7489cba7_92958774 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_12435704775c0fad7489cba7_92958774',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Id</th>
  <th>Sezon</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_3574976375c0fad7489e3b5_43296911 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_3574976375c0fad7489e3b5_43296911',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Id</th>
  <th class="searchable">Sezon</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_2970808725c0fad7489faf0_97884486 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_2970808725c0fad7489faf0_97884486',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['RokOd'];?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['RokDo'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
mecz/sezon/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
/" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż wszystkie mecze w sezonie">
        <span class="glyphicon glyphicon-th-list" aria-hidden="true"></span>
    </a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
sezon/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-danger btn-sm delete-button"
        data-toggle="tooltip" data-placement="top" title="Usuń">
        <span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span>
    </a>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
}
