<?php
/* Smarty version 3.1.33, created on 2019-01-21 22:25:29
  from 'C:\xampp\htdocs\projekt\templates\Access\passwordForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c4638c991cc68_23260515',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7cd3c5b219c11bde445f730c7683b755ab5bd6b1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Access\\passwordForm.html.tpl',
      1 => 1548105731,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c4638c991cc68_23260515 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group">
    <label for="haslo">Hasło</label>
    <input type="password" class="form-control" id="haslo" name="haslo" placeholder="Wprowadź nowe hasło">
</div><?php }
}
