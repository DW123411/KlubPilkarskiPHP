<?php
/* Smarty version 3.1.33, created on 2019-01-19 21:23:49
  from 'C:\xampp\htdocs\projekt\templates\Access\regForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c43875517ffa9_10688551',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '74d22ee5d4dfa1eb7572b7128c0cb73291a287a9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Access\\regForm.html.tpl',
      1 => 1547929420,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c43875517ffa9_10688551 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6054302045c438755160514_96291370', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17147207625c438755163941_20662709', 'body');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_6054302045c438755160514_96291370 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_6054302045c438755160514_96291370',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Formularz rejestracji<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_17147207625c438755163941_20662709 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_17147207625c438755163941_20662709',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="container">
<form id="regform" action="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zarejestruj/" method="post">
  <div class="form-group">
    <label for="login">Login</label>
    <input type="text" class="form-control" id="login" name="login" placeholder="Wprowadź login">
  </div>
  <div class="form-group">
    <label for="imie">Imię</label>
    <input type="text" class="form-control" id="imie" name="imie" placeholder="Wprowadź imię">
  </div>
  <div class="form-group">
    <label for="nazwisko">Nazwisko</label>
    <input type="text" class="form-control" id="nazwisko" name="nazwisko" placeholder="Wprowadź Nazwisko">
  </div>
  <div class="form-group">
    <label for="haslo">Hasło</label>
    <input type="password" class="form-control" id="haslo" name="haslo" placeholder="Wprowadź hasło">
  </div>
  <div class="alert alert-danger collapse" role="alert"></div>
  <button type="submit" class="btn btn-default">Zarejestruj</button>
</form>
</div>
<?php
}
}
/* {/block 'body'} */
}
