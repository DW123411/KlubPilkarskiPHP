<?php
/* Smarty version 3.1.33, created on 2019-01-02 19:54:54
  from 'C:\xampp\htdocs\projekt\templates\baseTemplate.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d08fe11b8a4_30530573',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e29726f1481ddeb9a2e073bb2e731dae0db1b8c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\baseTemplate.html.tpl',
      1 => 1536075110,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./headerBlock.html.tpl' => 1,
    'file:./navbarBlock.html.tpl' => 1,
    'file:./bodyBlock.html.tpl' => 1,
    'file:./footerBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c2d08fe11b8a4_30530573 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:./headerBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:./navbarBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:./bodyBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:./footerBlock.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
