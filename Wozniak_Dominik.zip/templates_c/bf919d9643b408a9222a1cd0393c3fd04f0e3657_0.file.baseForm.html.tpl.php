<?php
/* Smarty version 3.1.33, created on 2019-01-12 17:24:22
  from 'C:\xampp\htdocs\projekt\templates\baseForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3a14b68d37f5_16628716',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf919d9643b408a9222a1cd0393c3fd04f0e3657' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\baseForm.html.tpl',
      1 => 1546355674,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c3a14b68d37f5_16628716 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8272289445c3a14b68c34e1_05877789', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15948566555c3a14b68c4c02_61517644', 'body');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_8272289445c3a14b68c34e1_05877789 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_8272289445c3a14b68c34e1_05877789',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Formularz dodawania<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_10445694555c3a14b68cee82_28286653 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_20327257455c3a14b68d0563_72727679 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'formBody'} */
/* {block 'button'} */
class Block_18392503395c3a14b68d1867_90305856 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Dodaj<?php
}
}
/* {/block 'button'} */
/* {block 'body'} */
class Block_15948566555c3a14b68c4c02_61517644 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_15948566555c3a14b68c4c02_61517644',
  ),
  'action' => 
  array (
    0 => 'Block_10445694555c3a14b68cee82_28286653',
  ),
  'formBody' => 
  array (
    0 => 'Block_20327257455c3a14b68d0563_72727679',
  ),
  'button' => 
  array (
    0 => 'Block_18392503395c3a14b68d1867_90305856',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form id="form" class="validate-form" action="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10445694555c3a14b68cee82_28286653', 'action', $this->tplIndex);
?>
" method="post">
  <div class="panel panel-default">
    <div class="panel-body">
      <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20327257455c3a14b68d0563_72727679', 'formBody', $this->tplIndex);
?>

    </div>
    <div class="panel-footer text-right">
        <button type="submit" class="btn btn-success"><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18392503395c3a14b68d1867_90305856', 'button', $this->tplIndex);
?>
</button>
    </div>
  </div>
</form>
<?php
}
}
/* {/block 'body'} */
}
