<?php
/* Smarty version 3.1.33, created on 2019-01-02 19:54:54
  from 'C:\xampp\htdocs\projekt\templates\modals\base.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d08fe27dbd3_75017566',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '40d0c308bd95062d51bb8722b4d3d180643b38be' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\modals\\base.html.tpl',
      1 => 1537525824,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2d08fe27dbd3_75017566 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!-- BEGIN OF MODAL WINDOW -->
<div class="modal fade" id="<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6639246625c2d08fe278ba0_32652225', 'id');
?>
"
     tabindex="-1" role="dialog"
     aria-labelledby="<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8606553855c2d08fe27a3a9_79846600', 'id');
?>
-title" aria-hidden="true">
     <div class="modal-dialog <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9299686095c2d08fe27b8b3_36179021', 'size');
?>
">
        <div class="modal-content">
            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2395683255c2d08fe27cbd6_16698658', 'content');
?>

        </div>
     </div>
</div><!-- END OF MODAL WINDOW -->
<?php }
/* {block 'id'} */
class Block_6639246625c2d08fe278ba0_32652225 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'id' => 
  array (
    0 => 'Block_6639246625c2d08fe278ba0_32652225',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
modal<?php
}
}
/* {/block 'id'} */
/* {block 'id'} */
class Block_8606553855c2d08fe27a3a9_79846600 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'id' => 
  array (
    0 => 'Block_8606553855c2d08fe27a3a9_79846600',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
modal<?php
}
}
/* {/block 'id'} */
/* {block 'size'} */
class Block_9299686095c2d08fe27b8b3_36179021 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'size' => 
  array (
    0 => 'Block_9299686095c2d08fe27b8b3_36179021',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'size'} */
/* {block 'content'} */
class Block_2395683255c2d08fe27cbd6_16698658 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_2395683255c2d08fe27cbd6_16698658',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

            <?php
}
}
/* {/block 'content'} */
}
