<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:27:41
  from 'C:\xampp\htdocs\projekt\templates\ZawodnikMecz\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5b7d89c123_94824327',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f390d7b22c85138a0b5b76a2a8c9fcfce597fe15' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ZawodnikMecz\\showOne.html.tpl',
      1 => 1547656056,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5b7d89c123_94824327 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12183149085c3f5b7d861ff2_11148109', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16804971685c3f5b7d863e73_92743973', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8060747965c3f5b7d892101_58517626', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_12183149085c3f5b7d861ff2_11148109 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_12183149085c3f5b7d861ff2_11148109',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o występie zawodnika<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_16804971685c3f5b7d863e73_92743973 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_16804971685c3f5b7d863e73_92743973',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['data']->value['IdZ']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['data']->value['IdZ']]['Nazwisko'];?>
</h3>
        <p>Mecz: <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['IdKlubGoscie']]['Nazwa'];?>
</p>
        <p>Data: <?php echo $_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['Data'];?>
</p>
        <p>Pozycja: <?php echo $_smarty_tpl->tpl_vars['data']->value['Pozycja'];?>
</p>
        <p>Czas gry: <?php echo $_smarty_tpl->tpl_vars['data']->value['MinutyOd'];?>
-<?php echo $_smarty_tpl->tpl_vars['data']->value['MinutyDo'];?>
</p>
        <p>Bramki: <?php echo $_smarty_tpl->tpl_vars['data']->value['Bramki'];?>
</p>
        <p>Asysty: <?php echo $_smarty_tpl->tpl_vars['data']->value['Asysty'];?>
</p>
        <p>Kartki żółte: <?php echo $_smarty_tpl->tpl_vars['data']->value['KartkiZolte'];?>
</p>
        <p>Kartki czerwone: <?php echo $_smarty_tpl->tpl_vars['data']->value['KartkiCzerwone'];?>
</p>
        <p>Podania udane/nieudane: <?php echo $_smarty_tpl->tpl_vars['data']->value['PodaniaUdane'];?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value['PodaniaNieudane'];?>
</p>
        <p class="text-right">
          <button type="button" class="btn btn-warning edit-button"
              data-url="zawodnikmecz/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"
              data-toggle="tooltip" data-placement="top" title="Modyfikuj występ zawodnika w meczu">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Modyfikuj występ zawodnika w meczu
          </button>
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="zawodnikmecz/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['data']->value['IdM']]['IdKlubGoscie']]['Nazwa'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń występ zawodnika w meczu">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń występ zawodnika w meczu
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_8060747965c3f5b7d892101_58517626 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_8060747965c3f5b7d892101_58517626',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
