<?php
/* Smarty version 3.1.33, created on 2019-01-02 20:34:09
  from 'C:\xampp\htdocs\projekt\templates\Trener\trenerForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2d1231118622_70928236',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'baac6f58d8332b48785352ea9d96dcb95570e5ca' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Trener\\trenerForm.html.tpl',
      1 => 1546368819,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2d1231118622_70928236 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group has-feedback">
  <label for="imie">Imię</label>
  <input class="form-control" id="imie" name="imie" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Imie'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Imie'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="40"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<div class="form-group has-feedback">
  <label for="nazwisko">Nazwisko</label>
  <input class="form-control" id="nazwisko" name="nazwisko" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['Nazwisko'])) {
echo $_smarty_tpl->tpl_vars['data']->value['Nazwisko'];
}?>"
    type="text"
    data-minlength="2"
    maxlength="50"
    data-required-error="Pole wymagane"
    data-minlength-error="Minimalna długość to 2 znaki"
    required>
  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
  <div class="help-block with-errors"></div>
</div>
<?php }
}
