<?php
/* Smarty version 3.1.33, created on 2019-01-16 16:53:03
  from 'C:\xampp\htdocs\projekt\templates\Klub\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f535f3dd132_43946330',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd075dea0ebf238813ce2fd5c3ecccd2d793bccfb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Klub\\showOne.html.tpl',
      1 => 1547652263,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f535f3dd132_43946330 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13341143065c3f535f3b3993_41882680', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20857403955c3f535f3b8771_12211248', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19197045995c3f535f3d3aa4_60559539', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_13341143065c3f535f3b3993_41882680 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_13341143065c3f535f3b3993_41882680',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o klubie<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_20857403955c3f535f3b8771_12211248 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_20857403955c3f535f3b8771_12211248',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];?>
</h3>
        <p>Siedziba: <?php echo $_smarty_tpl->tpl_vars['data']->value['Siedziba'];?>
</p>
        <p>Opis: <?php echo $_smarty_tpl->tpl_vars['data']->value['Opis'];?>
</p>
        <p>Trener: <?php echo $_smarty_tpl->tpl_vars['coaches']->value[$_smarty_tpl->tpl_vars['data']->value['IdT']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['coaches']->value[$_smarty_tpl->tpl_vars['data']->value['IdT']]['Nazwisko'];?>
</p>
        <p class="text-right">
          <button type="button" class="btn btn-warning edit-button"
              data-url="klub/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"
              data-toggle="tooltip" data-placement="top" title="Modyfikuj klub">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Modyfikuj klub
          </button>
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="klub/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń klub">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń klub
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_19197045995c3f535f3d3aa4_60559539 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_19197045995c3f535f3d3aa4_60559539',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
