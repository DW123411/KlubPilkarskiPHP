<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:27:01
  from 'C:\xampp\htdocs\projekt\templates\ZawodnikMecz\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5b555fffe4_31266650',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'aa5564d69e008a05045df2e0ab211edfcdb35a09' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\ZawodnikMecz\\showAll.html.tpl',
      1 => 1547655844,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5b555fffe4_31266650 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13338789075c3f5b5555fc34_53706957', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4443886795c3f5b55562555_65056334', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14203415775c3f5b55566bf7_05985209', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13211916085c3f5b55568a89_51747992', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4338684135c3f5b5557a9e9_82416075', 'tbody');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19153226885c3f5b555e1621_36186848', 'footer');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_13338789075c3f5b5555fc34_53706957 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_13338789075c3f5b5555fc34_53706957',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista występów zawodników w meczach<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_3728670795c3f5b55563d52_14301874 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <button type="button" class="btn btn-primary add-button"
            data-url="zawodnikmecz/formularz/"
            data-toggle="tooltip" data-placement="top" title="Dodaj występ zawodnika w meczu">
            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj występ zawodnika w meczu
      </button>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_4443886795c3f5b55562555_65056334 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_4443886795c3f5b55562555_65056334',
  ),
  'groupAction' => 
  array (
    0 => 'Block_3728670795c3f5b55563d52_14301874',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3728670795c3f5b55563d52_14301874', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_14203415775c3f5b55566bf7_05985209 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_14203415775c3f5b55566bf7_05985209',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Data</th>
  <th>Mecz</th>
  <th>Zawodnik</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_13211916085c3f5b55568a89_51747992 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_13211916085c3f5b55568a89_51747992',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Data</th>
  <th class="searchable">Mecz</th>
  <th class="searchable">Zawodnik</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_4338684135c3f5b5557a9e9_82416075 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_4338684135c3f5b5557a9e9_82416075',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['Data'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['IdKlubGoscie']]['Nazwa'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['row']->value['IdZ']]['Imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['players']->value[$_smarty_tpl->tpl_vars['row']->value['IdZ']]['Nazwisko'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
zawodnikmecz/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <button type="button" class="btn btn-danger btn-sm delete-button"
          data-url="zawodnikmecz/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
/"
          data-description="<?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['IdKlubGospodarze']]['Nazwa'];?>
 - <?php echo $_smarty_tpl->tpl_vars['clubs']->value[$_smarty_tpl->tpl_vars['matches']->value[$_smarty_tpl->tpl_vars['row']->value['IdM']]['IdKlubGoscie']]['Nazwa'];?>
"
          data-toggle="tooltip" data-placement="top" title="Usuń występ zawodnika w meczu">
          <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
    </button>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
/* {block 'footer'} */
class Block_19153226885c3f5b555e1621_36186848 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_19153226885c3f5b555e1621_36186848',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
