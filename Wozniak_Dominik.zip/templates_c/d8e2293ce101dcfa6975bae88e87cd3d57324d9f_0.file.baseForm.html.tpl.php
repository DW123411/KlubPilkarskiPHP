<?php
/* Smarty version 3.1.33, created on 2019-01-01 16:14:47
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\baseForm.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c2b83e7811f26_66011567',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd8e2293ce101dcfa6975bae88e87cd3d57324d9f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\baseForm.html.tpl',
      1 => 1546355674,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c2b83e7811f26_66011567 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15396514015c2b83e77f5cc5_25646344', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14940458765c2b83e77f7fd5_99672837', 'body');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_15396514015c2b83e77f5cc5_25646344 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_15396514015c2b83e77f5cc5_25646344',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Formularz dodawania<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_9375305645c2b83e780d6e6_28457754 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_7178771395c2b83e780ec08_00385576 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'formBody'} */
/* {block 'button'} */
class Block_1233065455c2b83e780fe25_85753020 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Dodaj<?php
}
}
/* {/block 'button'} */
/* {block 'body'} */
class Block_14940458765c2b83e77f7fd5_99672837 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_14940458765c2b83e77f7fd5_99672837',
  ),
  'action' => 
  array (
    0 => 'Block_9375305645c2b83e780d6e6_28457754',
  ),
  'formBody' => 
  array (
    0 => 'Block_7178771395c2b83e780ec08_00385576',
  ),
  'button' => 
  array (
    0 => 'Block_1233065455c2b83e780fe25_85753020',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form id="form" class="validate-form" action="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9375305645c2b83e780d6e6_28457754', 'action', $this->tplIndex);
?>
" method="post">
  <div class="panel panel-default">
    <div class="panel-body">
      <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7178771395c2b83e780ec08_00385576', 'formBody', $this->tplIndex);
?>

    </div>
    <div class="panel-footer text-right">
        <button type="submit" class="btn btn-success"><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1233065455c2b83e780fe25_85753020', 'button', $this->tplIndex);
?>
</button>
    </div>
  </div>
</form>
<?php
}
}
/* {/block 'body'} */
}
