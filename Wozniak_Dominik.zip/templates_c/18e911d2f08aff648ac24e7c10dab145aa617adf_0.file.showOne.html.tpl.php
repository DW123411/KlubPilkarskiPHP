<?php
/* Smarty version 3.1.33, created on 2019-01-16 17:26:44
  from 'C:\xampp\htdocs\projekt\templates\Stadion\showOne.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3f5b448fe3a9_08962746',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '18e911d2f08aff648ac24e7c10dab145aa617adf' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\templates\\Stadion\\showOne.html.tpl',
      1 => 1547655688,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../modals/deleteConfirmBlock.html.tpl' => 1,
  ),
),false)) {
function content_5c3f5b448fe3a9_08962746 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10402601895c3f5b448df923_01741462', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13701446805c3f5b448e1946_68022822', 'body');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8407609935c3f5b448f52f9_75670561', 'footer');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_10402601895c3f5b448df923_01741462 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_10402601895c3f5b448df923_01741462',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Szczegółowe informacje o stadionie<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_13701446805c3f5b448e1946_68022822 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_13701446805c3f5b448e1946_68022822',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
  <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
    <div class="thumbnail">
      <div class="caption">
        <h3><?php echo $_smarty_tpl->tpl_vars['data']->value['Miejscowosc'];?>
 - <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];?>
</h3>
        <p>Pojemność: <?php echo $_smarty_tpl->tpl_vars['data']->value['Pojemnosc'];?>
</p>
        <p class="text-right">
          <button type="button" class="btn btn-warning edit-button"
              data-url="stadion/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"
              data-toggle="tooltip" data-placement="top" title="Modyfikuj stadion">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Modyfikuj stadion
          </button>
          <button type="button" class="btn btn-danger btn-sm delete-button"
                data-url="stadion/usun/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/"
                data-description="<?php echo $_smarty_tpl->tpl_vars['data']->value['Miejscowosc'];?>
 - <?php echo $_smarty_tpl->tpl_vars['data']->value['Nazwa'];?>
"
                data-toggle="tooltip" data-placement="top" title="Usuń stadion">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Usuń stadion
          </button>
        </p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
/* {/block 'body'} */
/* {block 'footer'} */
class Block_8407609935c3f5b448f52f9_75670561 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_8407609935c3f5b448f52f9_75670561',
  ),
);
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender('file:../modals/deleteConfirmBlock.html.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'footer'} */
}
