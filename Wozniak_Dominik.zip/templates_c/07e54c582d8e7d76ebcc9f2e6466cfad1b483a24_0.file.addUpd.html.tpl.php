<?php
/* Smarty version 3.1.33, created on 2018-12-26 20:31:45
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Zawodnik\addUpd.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c23d721cff330_15707013',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '07e54c582d8e7d76ebcc9f2e6466cfad1b483a24' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Zawodnik\\addUpd.html.tpl',
      1 => 1545852697,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./zawodnikForm.html.tpl' => 1,
  ),
),false)) {
function content_5c23d721cff330_15707013 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18550846015c23d721cdf656_48324812', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12303285875c23d721ce1496_32920504', 'action');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4459634425c23d721cf5c15_63026511', 'formBody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseForm.html.tpl");
}
/* {block 'title'} */
class Block_18550846015c23d721cdf656_48324812 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_18550846015c23d721cdf656_48324812',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Modyfikuj zawodnika<?php
}
}
/* {/block 'title'} */
/* {block 'action'} */
class Block_12303285875c23d721ce1496_32920504 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'action' => 
  array (
    0 => 'Block_12303285875c23d721ce1496_32920504',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

zawodnik/mod/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
/
<?php
}
}
/* {/block 'action'} */
/* {block 'formBody'} */
class Block_4459634425c23d721cf5c15_63026511 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'formBody' => 
  array (
    0 => 'Block_4459634425c23d721cf5c15_63026511',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <?php $_smarty_tpl->_subTemplateRender("file:./zawodnikForm.html.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'formBody'} */
}
