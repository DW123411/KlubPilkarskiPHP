<?php
/* Smarty version 3.1.33, created on 2018-12-12 15:47:02
  from 'C:\xampp\htdocs\ZPAI\projekt\templates\Trener\showAll.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c111f66b07f51_56705574',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8708cb164d0efe87dba4346d3fe892d230e281e3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ZPAI\\projekt\\templates\\Trener\\showAll.html.tpl',
      1 => 1544625983,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c111f66b07f51_56705574 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1188749965c111f66a84be0_87523236', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1259109695c111f66a86d73_23303359', 'checkableFormHeader');
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6542218585c111f66a9f119_18747024', 'thead');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10204874115c111f66ad71d9_57677024', 'tfoot');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8728732585c111f66ad8eb0_46101035', 'tbody');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../tableTemplate.html.tpl");
}
/* {block 'title'} */
class Block_1188749965c111f66a84be0_87523236 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_1188749965c111f66a84be0_87523236',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Lista trenerów<?php
}
}
/* {/block 'title'} */
/* {block 'groupAction'} */
class Block_12852164435c111f66a88183_32193193 extends Smarty_Internal_Block
{
public $prepend = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
trener/formularz/" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Dodaj trenera">
        <span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span>
        Dodaj trenera
    </a>
  <?php
}
}
/* {/block 'groupAction'} */
/* {block 'checkableFormHeader'} */
class Block_1259109695c111f66a86d73_23303359 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'checkableFormHeader' => 
  array (
    0 => 'Block_1259109695c111f66a86d73_23303359',
  ),
  'groupAction' => 
  array (
    0 => 'Block_12852164435c111f66a88183_32193193',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div  style="padding-bottom: 50px"><span class="btn-group pull-right">
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12852164435c111f66a88183_32193193', 'groupAction', $this->tplIndex);
?>

</span></div>
<?php
}
}
/* {/block 'checkableFormHeader'} */
/* {block 'thead'} */
class Block_6542218585c111f66a9f119_18747024 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'thead' => 
  array (
    0 => 'Block_6542218585c111f66a9f119_18747024',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th>Imie</th>
  <th>Nazwisko</th>
  <th class="hidden-print"></th>
<?php
}
}
/* {/block 'thead'} */
/* {block 'tfoot'} */
class Block_10204874115c111f66ad71d9_57677024 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tfoot' => 
  array (
    0 => 'Block_10204874115c111f66ad71d9_57677024',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <th class="searchable">Imie</th>
  <th class="searchable">Nazwisko</th>
  <th></th>
<?php
}
}
/* {/block 'tfoot'} */
/* {block 'tbody'} */
class Block_8728732585c111f66ad8eb0_46101035 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'tbody' => 
  array (
    0 => 'Block_8728732585c111f66ad8eb0_46101035',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Imie'];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['row']->value['Nazwisko'];?>
</td>
  <td><span class="btn-group pull-right">
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
trener/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-primary btn-sm"
        data-toggle="tooltip" data-placement="top" title="Pokaż szczegółowe informacje">
        <span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span>
    </a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['protocol']->value;
echo $_SERVER['HTTP_HOST'];
echo $_smarty_tpl->tpl_vars['subdir']->value;?>
trener/usun/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
" type="button" class="btn btn-danger btn-sm delete-button"
        data-toggle="tooltip" data-placement="top" title="Usuń">
        <span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span>
    </a>
  </span></td>
<?php
}
}
/* {/block 'tbody'} */
}
